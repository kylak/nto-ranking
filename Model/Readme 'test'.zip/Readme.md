Here is a command to download the public CNTR collation : 
```
javac UpdateData.java -d ../Diverse/Generated\ Java\ classes/ && cd ../Diverse/Generated\ Java\ classes/ && java UpdateData && sh ../../Controller/.downloadData  && rm ../../Controller/.downloadData && cd ../../Model/
```
The downloaded files are located on ```Model/Data/New Testament/$TODAYSDATE$```

<br />
The Greek texts, the morphology and strongs numbers are from the CNTR (https://greekcntr.org/).

