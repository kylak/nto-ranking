|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
στόμα (n°4750)|edge, face, mouth|Jc 3:8-12|
ἰός (n°2447)|Judah|Jc 3:8-12|
κριτήριον (n°2922)|to judge, judgment  (seat)|Jc 2:5-7|
πλοῦτος (n°4149)|riches|1 Tim 6:17-19|
ἀπόστολος (n°652)|apostle, messenger, he that is sent|Heb 3:1|
προσωποληψία (n°4382)|respect of persons|Jc 2:1-4|
εὐχαριστία (n°2169)|thankfulness, (giving of) thanks(-giving)|1 Tim 2:1-2|
ἄρτος (n°740)|(shew-)bread, loaf|2 Thess 3:12|
χεῖλος (n°5491)|lip, shore|Heb 13:15|
ἀμοιβή (n°287)|vine|1 Tim 5:4|
ἔκβασις (n°1545)|end, way to escape|Heb 13:7|
ἄνθος (n°438)|fire of coals|Jc 1:10|
ἀσέβεια (n°763)|ungodly(-liness)|2 Tim 2:16|
μοιχαλίς (n°3428)|adulteress(-ous, -y)|Jc 4:4|
κατάρα (n°2671)|curse(-d,  ing)|Jc 3:8-12|
ποιητής (n°4163)|divers,  manifold|Jc 1:22|
πλάνη (n°4106)|deceit, to deceive,  delusion, error|Jc 5:20|
Πιλᾶτος (n°4091)|writing table|1 Tim 6:13|
σύνεσις (n°4907)|knowledge, understanding|2 Tim 2:7|
Λύστρα (n°3082)|ransom|2 Tim 3:10-11|
σπέρμα (n°4690)|issue, seed|2 Tim 2:8|
περισσεία (n°4050)|abundance(-ant, (-ly)),  superfluity|Jc 1:21|
ὕψος (n°5311)|be exalted, height,  (on) high|Jc 1:9|
φιλαδελφία (n°5360)|brotherly love (kindness), love of  the brethren|Heb 13:1|
ἀντιλογία (n°485)|contradiction,  gainsaying, strife|Heb 12:3|
φθόνος (n°5355)|envy|Jc 4:5|
ἐλπίς (n°1680)|me, mine own (self), myself|1 Thess 5:8|
ἐλαία (n°1636)|oil|Jc 3:8-12|
μεμβράνα (n°3200)|complainer|2 Tim 4:13|
πόρνη (n°4204)|harlot,  whore|Jc 2:20-26|
μαργαρίτης (n°3135)| Mary|1 Tim 2:9-10|
γέλως (n°1071)|laughter|Jc 4:9|
ἔχθρα (n°2189)|enmity, hatred|Jc 4:4|
θεοσέβεια (n°2317)|godliness|1 Tim 2:9-10|
νομοθέτης (n°3550)|lawgiver|Jc 4:12|
συκῆ (n°4808)|fig tree|Jc 3:8-12|
προφητεία (n°4394)|prophecy,  prophesying|1 Thess 5:20|
Λουκᾶς (n°3065)|washing|2 Tim 4:11|
κενοφωνία (n°2757)|vain|2 Tim 2:16|
ἀδηλότης (n°83)|X uncertain|1 Tim 6:17-19|
σταυρός (n°4716)|cross|Heb 12:1-2|
σῦκον (n°4810)|accuse falsely, take by false accusation|Jc 3:8-12|
μόρφωσις (n°3446)|form|2 Tim 3:1-5|
ἀφορμή (n°874)|occasion|1 Tim 5:14|
ἐπιφάνεια (n°2015)|appearing, brightness|1 Tim 6:14|
βαπτισμός (n°909)|baptism, washing|Heb 6:1-3|
βρῶσις (n°1035)|eating,  food, meat|Heb 12:14-16|
θάνατος (n°2288)|X deadly, (be…) death|Jc 5:20|
αἰσχύνη (n°152)|dishonesty,  shame|Heb 12:1-2|
κλύδων (n°2830)|toss to and fro|Jc 1:5-6|
καταστροφή (n°2692)|overthrow, subverting|2 Tim 2:14|
βασιλεύς (n°935)|king|1 Tim 2:1-2|
εὐεργεσία (n°2108)|benefit, good  deed done|1 Tim 6:2|
πλήκτης (n°4131)|striker|1 Tim 3:2-4|
χόρτος (n°5528)|entreat, use|Jc 1:10|
εἶδος (n°1491)|appearance,  fashion, shape, sight|1 Thess 5:22|
ἐντολή (n°1785)|commandment, precept|1 Tim 6:14|
πικρία (n°4088)|bitterness|Heb 12:14-16|
ἔλαιον (n°1637)|oil|Jc 5:14|
φιλονεξία (n°5381)|entertain stranger, hospitality|Heb 13:2|
λοιδορία (n°3059)|railing, reproach(-fully)|1 Tim 5:14|
φελόνης (n°5341)| cloke|2 Tim 4:13|
κλῆσις (n°2821)|calling|Heb 3:1|
ἀπώλεια (n°684)|damnable(-nation), destruction, die, perdition, X  perish, pernicious ways, waste|2 Thess 2:3|
εὐλογία (n°2129)|blessing (a matter of) bounty (X -tifully), fair speech|Jc 3:8-12|
κατήφεια (n°2726)|heaviness|Jc 4:9|
αἰτία (n°156)|accusation,  case, cause, crime, fault, (wh-)ere(-fore)|2 Tim 1:6|
εὐλάβεια (n°2124)|fear(-ed)|Heb 12:28|
ἀτμίς (n°822)|vapour|Jc 4:14|
ἐπίσκοπος (n°1985)|bishop, overseer|1 Tim 3:2-4|
θυσία (n°2378)|sacrifice|Heb 13:15|
ἁγιασμός (n°38)|holiness, sanctification|Heb 12:14-16|
πένθος (n°3997)|mourning, sorrow|Jc 4:9|
πόλις (n°4172)|city|Heb 13:13-14|
γλῶσσα (n°1100)|bag|Jc 3:8-12|
παροξυσμός (n°3948)|contention, provoke unto|Heb 10:24|
Μακεδονία (n°3109)|Macedonia|1 Thess 4:10|
ὑπεροχή (n°5247)|authority, excellency|1 Tim 2:1-2|
τροχιά (n°5163)|path|Heb 12:13|
πρωτοτόκια (n°4415)|birthright|Heb 12:14-16|
γονεύς (n°1118)|parent|2 Tim 3:1-5|
Κάρπος (n°2591)|Carpus|2 Tim 4:13|
ἀκροθίνιον (n°205)|spoils|Heb 7:4|
ἐπίγνωσις (n°1922)|(ac-)knowledge(-ing, - ment)|2 Tim 2:25|
νοῦς (n°3563)|mind,  understanding|2 Thess 2:1-2|
ἔτος (n°2094)|Eve|1 Tim 5:9-10|
βρῶμα (n°1033)|meat,  victuals|Heb 13:9|
κακοπάθεια (n°2552)|suffering affliction|Jc 5:10|
ἄμπελος (n°288)|vine|Jc 3:8-12|
ἀγών (n°73)|conflict, contention, fight, race|Heb 12:1-2|
Δαβίδ (n°1138)|David|2 Tim 2:8|
διδάσκαλος (n°1320)|doctor,  master, teacher|Jc 3:1|
ζήτησις (n°2214)|question|2 Tim 2:23|
θάλασσα (n°2281)|sea|Jc 1:5-6|
Τρωάς (n°5174)|eat|2 Tim 4:13|
μισθαποδοσία (n°3405)|recompence of reward|Heb 10:35|
μέλος (n°3196)|Melchi|Jc 4:1|
κληρονόμος (n°2818)|heir|Jc 2:5-7|
ἀπιστία (n°570)|unbelief|Heb 3:12|
ὑποτύπωσις (n°5296)|form, pattern|2 Tim 1:13|
μαρτυρία (n°3141)|record,  report, testimony, witness|1 Tim 3:7|
ἱματισμός (n°2441)|apparel (X -led), array, raiment, vesture|1 Tim 2:9-10|
παγίς (n°3803)|snare|1 Tim 3:7|
κοινωνός (n°2844)|companion, X fellowship,  partaker, partner|Heb 10:32-33|
κρίσις (n°2920)|to judge, judgment  (seat)|Jc 5:12|
συναγωγή (n°4864)|assembly, congregation, synagogue|Jc 2:1-4|
Ἠσαῦ (n°2269)|Esau|Heb 12:14-16|
γόνυ (n°1119)|bow the knee, kneel down|Heb 12:12|
τελειωτής (n°5051)|finisher|Heb 12:1-2|
ἔλεος (n°1656)|liberty|Heb 4:16|
μυστήριον (n°3466)| cannot see far off|1 Tim 3:8-9|
προδότης (n°4273)|betrayer, traitor|2 Tim 3:1-5|
ἀπάτη (n°539)|deceit(-ful, -fulness), deceivableness(-ving)|Heb 3:13|
φίλημα (n°5370)|kiss|1 Thess 5:26|
ἄθλησις (n°119)|fight|Heb 10:32-33|
ἀρχηγός (n°747)|author, captain, prince|Heb 12:1-2|
εὐαγγελιστής (n°2099)|evangelist|2 Tim 4:5|
ῥίζα (n°4491)|root|Heb 12:14-16|
ὀπή (n°3692)|cave, place|Jc 3:8-12|
βίος (n°979)|live|1 Tim 2:1-2|
ἔθος (n°1485)|custom, manner, be  wont|Heb 10:25|
οἶνος (n°3631)|wine|1 Tim 3:8-9|
τελειότης (n°5047)|perfection(-ness)|Heb 6:1-3|
ὑποπόδιον (n°5286)|footstool|Jc 2:1-4|
γάμος (n°1062)|Gedeon  (in the King James Version)|Heb 13:4|
πατριάρχης (n°3966)|patriarch|Heb 7:4|
χάρισμα (n°5486)|(free)  gift|2 Tim 1:6|
γράμμα (n°1121)|bill, learning, letter, scripture, writing, written|2 Tim 3:14-15|
προσευχή (n°4335)|X  pray earnestly, prayer|1 Tim 2:1-2|
δοκίμιον (n°1383)|trial, trying|Jc 1:2-3|
ὑετός (n°5205)|adoption (of children, of sons)|Jc 5:7|
κακία (n°2549)|evil, malice(-iousness),  naughtiness, wickedness|Jc 1:21|
πρόθεσις (n°4286)|purpose, shew(-bread)|2 Tim 3:10-11|
βοήθεια (n°996)|help|Heb 4:16|
ὁμοίωσις (n°3669)|similitude|Jc 3:8-12|
πληροφορία (n°4136)|(full) assurance|Heb 10:22|
καιρός (n°2540)|Cæsar|2 Tim 3:1-5|
ἀπείθεια (n°543)|disobedience,  unbelief|Heb 4:11|
θλῖψις (n°2347)|afflicted(-tion),  anguish, burdened, persecution, tribulation, trouble|Heb 10:32-33|
καταστολή (n°2689)|apparel|1 Tim 2:9-10|
ἀλαζών (n°213)|unutterable, which cannot be uttered|2 Tim 3:1-5|
Ῥαάβ (n°4460)|Rahab|Jc 2:20-26|
σοφία (n°4678)|wisdom|Jc 3:13-14|
Πόντιος (n°4194)|journey(-ing), ways|1 Tim 6:13|
βιβλίον (n°975)|bill, book, scroll, writing|2 Tim 4:13|
Ἰκόνιον (n°2430)|Iconium|2 Tim 3:10-11|
ἀποστασία (n°646)|falling away, forsake|2 Thess 2:3|
ἡδονή (n°2237)|mint|Jc 4:1|
ὄγκος (n°3591)|weight|Heb 12:1-2|
ἀνάστασις (n°386)|raised to  life again, resurrection, rise from the dead, that should rise, rising  again|Heb 6:1-3|
ἐργάτης (n°2040)|labourer, worker(-men)|2 Tim 2:15|
ἀπόλαυσις (n°619)|enjoy(-ment)|1 Tim 6:17-19|
πλέγμα (n°4117)|broidered hair|1 Tim 2:9-10|
περικεφαλαία (n°4030)|helmet|1 Thess 5:8|
χρυσός (n°5557)|gold|1 Tim 2:9-10|
ἐλευθερία (n°1657)|liberty|Jc 2:12|
πλῆθος (n°4128)|bundle,  company, multitude|Jc 5:20|
τροφή (n°5160)|food, meat|Jc 2:14-16|
Ἀντιόχεια (n°490)|of Antioch|2 Tim 3:10-11|
