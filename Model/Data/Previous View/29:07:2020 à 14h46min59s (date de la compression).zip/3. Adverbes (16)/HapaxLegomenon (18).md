|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
λοιπόν (n°3063)|besides, finally, furthermore, (from) henceforth,  moreover, now, + it remaineth, then|1 Thess 4:1|
ἔξωθεν (n°1855)|out(-side, -ward, - wardly), (from)  without|1 Tim 3:7|
πλουσίως (n°4146)|abundantly, richly|1 Tim 6:17-19|
εὐκαίρως (n°2122)|conveniently, in season|2 Tim 4:2|
σήμερον (n°4594)|this  (to-)day|Heb 3:13|
πάλιν (n°3825)|again|Heb 6:1-3|
εὐαρέστως (n°2102)|acceptably, + please well|Heb 12:28|
ὁμοίως (n°3668)|likewise, so|Jc 2:20-26|
ἐκεῖ (n°1563)|from that place, (from) thence, there|Jc 2:1-4|
ἁπλῶς (n°574)|(X  here-)after, ago, at, because of, before, by (the space of), for(-th),  from, in, (out) of, off, (up-)on(-ce), since, with|Jc 1:5-6|
ἀκαίρως (n°171)|out of season|2 Tim 4:2|
ἀδιαλείπτως (n°89)|without ceasing|1 Thess 5:17|
ἀμέμπτως (n°274)|blameless, unblamably|1 Thess 5:23|
ἄνω (n°507)|above, brim, high, up|Heb 12:14-16|
πόθεν (n°4159)|whence|Jc 4:1|
ἔπειτα (n°1899)|after that(-ward), then|Jc 4:14|
ἐντεῦθεν (n°1782)|(from) hence, on either side|Jc 4:1|
μήποτε (n°3379)|if  peradventure, lest (at any time, haply), not at all, whether or not|2 Tim 2:25|
