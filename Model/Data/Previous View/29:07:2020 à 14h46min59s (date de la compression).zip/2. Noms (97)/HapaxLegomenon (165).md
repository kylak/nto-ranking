|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
γόνυ (n°1119)|bow the knee, kneel down|Heb 12:12|
ἄμπελος (n°288)|vine|Jc 3:8-12|
πρόθεσις (n°4286)|purpose, shew(-bread)|2 Tim 3:10-11|
ἀπιστία (n°570)|unbelief|Heb 3:12|
στόμα (n°4750)|edge, face, mouth|Jc 3:8-12|
ἔλαιον (n°1637)|oil|Jc 5:14|
ὑετός (n°5205)|adoption (of children, of sons)|Jc 5:7|
ὁμοίωσις (n°3669)|similitude|Jc 3:8-12|
πειρασμός (n°3986)|temptation, X try|Jc 1:2-3|
φιλονεξία (n°5381)|entertain stranger, hospitality|Heb 13:2|
εὐλάβεια (n°2124)|fear(-ed)|Heb 12:28|
εὐεργεσία (n°2108)|benefit, good  deed done|1 Tim 6:2|
κακοπάθεια (n°2552)|suffering affliction|Jc 5:10|
περισσεία (n°4050)|abundance(-ant, (-ly)),  superfluity|Jc 1:21|
πλῆθος (n°4128)|bundle,  company, multitude|Jc 5:20|
σύνεσις (n°4907)|knowledge, understanding|2 Tim 2:7|
Λουκᾶς (n°3065)|washing|2 Tim 4:11|
μέλος (n°3196)|Melchi|Jc 4:1|
βρῶσις (n°1035)|eating,  food, meat|Heb 12:14-16|
βοήθεια (n°996)|help|Heb 4:16|
εὐχαριστία (n°2169)|thankfulness, (giving of) thanks(-giving)|1 Tim 2:1-2|
φίλημα (n°5370)|kiss|1 Thess 5:26|
παροξυσμός (n°3948)|contention, provoke unto|Heb 10:24|
ζήτησις (n°2214)|question|2 Tim 2:23|
φελόνης (n°5341)| cloke|2 Tim 4:13|
ζυγός (n°2218)|leaven|1 Tim 6:1|
ἀπώλεια (n°684)|damnable(-nation), destruction, die, perdition, X  perish, pernicious ways, waste|2 Thess 2:3|
βίος (n°979)|live|1 Tim 2:1-2|
εἶδος (n°1491)|appearance,  fashion, shape, sight|1 Thess 5:22|
μαργαρίτης (n°3135)| Mary|1 Tim 2:9-10|
Λύστρα (n°3082)|ransom|2 Tim 3:10-11|
Μακεδονία (n°3109)|Macedonia|1 Thess 4:10|
κλύδων (n°2830)|toss to and fro|Jc 1:5-6|
ἀφορμή (n°874)|occasion|1 Tim 5:14|
εὐλογία (n°2129)|blessing (a matter of) bounty (X -tifully), fair speech|Jc 3:8-12|
πατριάρχης (n°3966)|patriarch|Heb 7:4|
χρυσός (n°5557)|gold|1 Tim 2:9-10|
ἐπίσκοπος (n°1985)|bishop, overseer|1 Tim 3:2-4|
σωφροσύνη (n°4997)|soberness, sobriety|1 Tim 2:9-10|
πρωτοτόκια (n°4415)|birthright|Heb 12:14-16|
ἀπείθεια (n°543)|disobedience,  unbelief|Heb 4:11|
αἰσχύνη (n°152)|dishonesty,  shame|Heb 12:1-2|
ἀπάτη (n°539)|deceit(-ful, -fulness), deceivableness(-ving)|Heb 3:13|
θώραξ (n°2382)|Jairus|1 Thess 5:8|
ἀλαζών (n°213)|unutterable, which cannot be uttered|2 Tim 3:1-5|
ἐπιφάνεια (n°2015)|appearing, brightness|1 Tim 6:14|
προσωποληψία (n°4382)|respect of persons|Jc 2:1-4|
πλοῦτος (n°4149)|riches|1 Tim 6:17-19|
δέσμιος (n°1198)|in bonds, prisoner|2 Tim 1:8|
τροφή (n°5160)|food, meat|Jc 2:14-16|
τελειωτής (n°5051)|finisher|Heb 12:1-2|
κοινωνός (n°2844)|companion, X fellowship,  partaker, partner|Heb 10:32-33|
σταυρός (n°4716)|cross|Heb 12:1-2|
βιβλίον (n°975)|bill, book, scroll, writing|2 Tim 4:13|
Τρωάς (n°5174)|eat|2 Tim 4:13|
ἐλαία (n°1636)|oil|Jc 3:8-12|
Ἰκόνιον (n°2430)|Iconium|2 Tim 3:10-11|
πλάνη (n°4106)|deceit, to deceive,  delusion, error|Jc 5:20|
γάμος (n°1062)|Gedeon  (in the King James Version)|Heb 13:4|
μισθαποδοσία (n°3405)|recompence of reward|Heb 10:35|
ἀγών (n°73)|conflict, contention, fight, race|Heb 12:1-2|
ἀπόστολος (n°652)|apostle, messenger, he that is sent|Heb 3:1|
ταλαιπωρία (n°5004)|misery|Jc 5:1|
φθόνος (n°5355)|envy|Jc 4:5|
ἱματισμός (n°2441)|apparel (X -led), array, raiment, vesture|1 Tim 2:9-10|
θάλασσα (n°2281)|sea|Jc 1:5-6|
βασιλεύς (n°935)|king|1 Tim 2:1-2|
ταπείνωσις (n°5014)|humiliation, be made low,  low estate, vile|Jc 1:10|
μεμβράνα (n°3200)|complainer|2 Tim 4:13|
πικρία (n°4088)|bitterness|Heb 12:14-16|
καταστολή (n°2689)|apparel|1 Tim 2:9-10|
ἐντολή (n°1785)|commandment, precept|1 Tim 6:14|
διδάσκαλος (n°1320)|doctor,  master, teacher|Jc 3:1|
Δαβίδ (n°1138)|David|2 Tim 2:8|
αἰτία (n°156)|accusation,  case, cause, crime, fault, (wh-)ere(-fore)|2 Tim 1:6|
γλῶσσα (n°1100)|bag|Jc 3:8-12|
μαρτυρία (n°3141)|record,  report, testimony, witness|1 Tim 3:7|
χάρισμα (n°5486)|(free)  gift|2 Tim 1:6|
βρῶμα (n°1033)|meat,  victuals|Heb 13:9|
Ἀντιόχεια (n°490)|of Antioch|2 Tim 3:10-11|
θεοσέβεια (n°2317)|godliness|1 Tim 2:9-10|
ἐπίγνωσις (n°1922)|(ac-)knowledge(-ing, - ment)|2 Tim 2:25|
οἶνος (n°3631)|wine|1 Tim 3:8-9|
Πιλᾶτος (n°4091)|writing table|1 Tim 6:13|
ἁγιασμός (n°38)|holiness, sanctification|Heb 12:14-16|
πόρνη (n°4204)|harlot,  whore|Jc 2:20-26|
ἀνάστασις (n°386)|raised to  life again, resurrection, rise from the dead, that should rise, rising  again|Heb 6:1-3|
Ἠσαῦ (n°2269)|Esau|Heb 12:14-16|
ἀκροθίνιον (n°205)|spoils|Heb 7:4|
γέλως (n°1071)|laughter|Jc 4:9|
ὄγκος (n°3591)|weight|Heb 12:1-2|
ἔτος (n°2094)|Eve|1 Tim 5:9-10|
χεῖλος (n°5491)|lip, shore|Heb 13:15|
Κάρπος (n°2591)|Carpus|2 Tim 4:13|
σοφία (n°4678)|wisdom|Jc 3:13-14|
περικεφαλαία (n°4030)|helmet|1 Thess 5:8|
μοιχαλίς (n°3428)|adulteress(-ous, -y)|Jc 4:4|
εὐαγγελιστής (n°2099)|evangelist|2 Tim 4:5|
ἀποστασία (n°646)|falling away, forsake|2 Thess 2:3|
θύρα (n°2374)|shield|Jc 5:9|
Ῥαάβ (n°4460)|Rahab|Jc 2:20-26|
καταστροφή (n°2692)|overthrow, subverting|2 Tim 2:14|
ἀρχηγός (n°747)|author, captain, prince|Heb 12:1-2|
δεσπότης (n°1203)|Lord, master|1 Tim 6:1|
κλῆσις (n°2821)|calling|Heb 3:1|
τελειότης (n°5047)|perfection(-ness)|Heb 6:1-3|
ῥίζα (n°4491)|root|Heb 12:14-16|
τόπος (n°5117)|as large, so great (long, many, much),  these many|1 Tim 2:8|
γονεύς (n°1118)|parent|2 Tim 3:1-5|
πένθος (n°3997)|mourning, sorrow|Jc 4:9|
ὀπή (n°3692)|cave, place|Jc 3:8-12|
κριτήριον (n°2922)|to judge, judgment  (seat)|Jc 2:5-7|
καιρός (n°2540)|Cæsar|2 Tim 3:1-5|
κατάρα (n°2671)|curse(-d,  ing)|Jc 3:8-12|
ὑποτύπωσις (n°5296)|form, pattern|2 Tim 1:13|
κατήφεια (n°2726)|heaviness|Jc 4:9|
ἐπαγγελία (n°1860)|message, promise|Heb 4:1|
ἔκβασις (n°1545)|end, way to escape|Heb 13:7|
νοῦς (n°3563)|mind,  understanding|2 Thess 2:1-2|
πλήκτης (n°4131)|striker|1 Tim 3:2-4|
προφητεία (n°4394)|prophecy,  prophesying|1 Thess 5:20|
πλέγμα (n°4117)|broidered hair|1 Tim 2:9-10|
ποιητής (n°4163)|divers,  manifold|Jc 1:22|
θάνατος (n°2288)|X deadly, (be…) death|Jc 5:20|
παρεμβολή (n°3925)|army, camp, castle|Heb 13:13-14|
ἀπόλαυσις (n°619)|enjoy(-ment)|1 Tim 6:17-19|
δοκίμιον (n°1383)|trial, trying|Jc 1:2-3|
ὕψος (n°5311)|be exalted, height,  (on) high|Jc 1:9|
ἔντευξις (n°1783)|intercession,  prayer|1 Tim 2:1-2|
ὑποπόδιον (n°5286)|footstool|Jc 2:1-4|
ἔχθρα (n°2189)|enmity, hatred|Jc 4:4|
ἡδονή (n°2237)|mint|Jc 4:1|
φιλαδελφία (n°5360)|brotherly love (kindness), love of  the brethren|Heb 13:1|
τροχιά (n°5163)|path|Heb 12:13|
ἀσέβεια (n°763)|ungodly(-liness)|2 Tim 2:16|
ἀντιλογία (n°485)|contradiction,  gainsaying, strife|Heb 12:3|
παγίς (n°3803)|snare|1 Tim 3:7|
βαπτισμός (n°909)|baptism, washing|Heb 6:1-3|
ἄθλησις (n°119)|fight|Heb 10:32-33|
ἐλευθερία (n°1657)|liberty|Jc 2:12|
σῦκον (n°4810)|accuse falsely, take by false accusation|Jc 3:8-12|
νομοθέτης (n°3550)|lawgiver|Jc 4:12|
κακία (n°2549)|evil, malice(-iousness),  naughtiness, wickedness|Jc 1:21|
προδότης (n°4273)|betrayer, traitor|2 Tim 3:1-5|
κληρονόμος (n°2818)|heir|Jc 2:5-7|
χόρτος (n°5528)|entreat, use|Jc 1:10|
ἀδελφή (n°79)|sister|Jc 2:14-16|
δοῦλος (n°1401)|bond(-man), servant|2 Tim 2:24|
ἔλεος (n°1656)|liberty|Heb 4:16|
μόρφωσις (n°3446)|form|2 Tim 3:1-5|
παραθήκη (n°3866)|committed unto|2 Tim 1:14|
αἴνεσις (n°133)|praise|Heb 13:15|
κρίσις (n°2920)|to judge, judgment  (seat)|Jc 5:12|
ὑπεροχή (n°5247)|authority, excellency|1 Tim 2:1-2|
λοιδορία (n°3059)|railing, reproach(-fully)|1 Tim 5:14|
ἰός (n°2447)|Judah|Jc 3:8-12|
ἀδηλότης (n°83)|X uncertain|1 Tim 6:17-19|
συναγωγή (n°4864)|assembly, congregation, synagogue|Jc 2:1-4|
ἀμοιβή (n°287)|vine|1 Tim 5:4|
μυστήριον (n°3466)| cannot see far off|1 Tim 3:8-9|
θλῖψις (n°2347)|afflicted(-tion),  anguish, burdened, persecution, tribulation, trouble|Heb 10:32-33|
γράμμα (n°1121)|bill, learning, letter, scripture, writing, written|2 Tim 3:14-15|
ἐργάτης (n°2040)|labourer, worker(-men)|2 Tim 2:15|
ἀτμίς (n°822)|vapour|Jc 4:14|
ἄρτος (n°740)|(shew-)bread, loaf|2 Thess 3:12|
