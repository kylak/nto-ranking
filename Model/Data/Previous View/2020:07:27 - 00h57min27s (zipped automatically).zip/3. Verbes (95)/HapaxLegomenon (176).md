|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
εὐθυμέω (n°2114)|be of good cheer (merry)|Jc 5:13|
πλουτέω (n°4147)|be  increased with goods, (be made, wax) rich|1 Tim 6:17-19|
ἑλκύω (n°1670)| Gentile, Greek|Jc 2:5-7|
ἐνοχλέω (n°1776)|trouble|Heb 12:14-16|
κηρύσσω (n°2784)|whale|2 Tim 4:2|
καταδυναστεύω (n°2616)|oppress|Jc 2:5-7|
λογίζομαι (n°3049)|conclude, (ac-)count (of), + despise, esteem,  impute, lay, number, reason, reckon, suppose, think (on)|Jc 2:20-26|
πρέπω (n°4241)|ambassage, message|1 Tim 2:9-10|
καθίζω (n°2523)|continue, set, sit (down), tarry|Heb 12:1-2|
λατρεύω (n°3000)|remnant|Heb 12:28|
ἐπίσταμαι (n°1987)|know, understand|Jc 4:14|
φαίνω (n°5316)| appear, seem,  be seen, shine, X think|Jc 4:14|
παραλαμβάνω (n°3880)|receive, take (unto, with)|2 Thess 3:6|
στρατεύομαι (n°4754)|soldier, (go to)  war(-fare)|Jc 4:1|
παραλογίζομαι (n°3884)|beguile, deceive|Jc 1:22|
θεατρίζω (n°2301)|make a gazing stock|Heb 10:32-33|
ἀνεμίζω (n°416)|drive with the wind|Jc 1:5-6|
ἐπιστρέφω (n°1994)|come (go) again, convert, (re-)turn (about, again)|Jc 5:20|
ἀντιλαμβάνομαι (n°482)|help, partaker, support|1 Tim 6:2|
ἀφοράω (n°872)|look|Heb 12:1-2|
ἐπιποθέω (n°1971)|(earnestly) desire (greatly),  (greatly) long (after), lust|Jc 4:5|
καταφρονέω (n°2706)|despise|Heb 12:1-2|
γεννάω (n°1080)|bear,  beget, be born, bring forth, conceive, be delivered of, gender, make,  spring|2 Tim 2:23|
ἀποτρέπω (n°665)|turn away|2 Tim 3:1-5|
ὀμνύω (n°3660)|with one accord (mind)|Jc 5:12|
ἀναθεωρέω (n°333)|behold, consider|Heb 13:7|
ξενίζω (n°3579)|entertain, lodge, (think it) strange|Heb 13:2|
θαῤῥέω (n°2292)|be bold, X boldly, have  confidence, be confident|Heb 13:5-6|
εὐσεβέω (n°2151)|show piety, worship|1 Tim 5:4|
εἰρηνεύω (n°1514)|be at (have, live in) peace, live  peaceably|1 Thess 5:13|
καταβάλλω (n°2598)|cast down, lay|Heb 6:1-3|
μεταστρέφω (n°3344)|pervert, turn|Jc 4:9|
ἐκτρέπω (n°1624)|avoid, turn (aside, out of the way)|Heb 12:13|
ὀρθοτομέω (n°3718)|come early in the morning|2 Tim 2:15|
ἀντέχομαι (n°472)|hold fast,  hold to, support|1 Thess 5:14|
δουλεύω (n°1398)|be in bondage, (do) serve(-ice)|1 Tim 6:2|
ἀναλαμβάνω (n°353)|receive up, take (in, unto, up)|2 Tim 4:11|
ἐργάζομαι (n°2038)|commit, do, labor  for, minister about, trade (by), work|1 Thess 4:11|
κατοικέω (n°2730)|dwell(-er), inhabitant(-ter)|Jc 4:5|
ἀγωνίζομαι (n°75)|fight, labor fervently, strive|1 Tim 6:12|
ὑπάγω (n°5217)|depart, get  hence, go (a-)way|Jc 2:14-16|
κακουχέω (n°2558)|which suffer  adversity, torment|Heb 13:3|
εὔχομαι (n°2172)|profitable, meet for  use|Jc 5:16|
σβέννυμι (n°4570)|thee, thou, X thy house|1 Thess 5:19|
ἀγαπάω (n°25)|(be-)love(-ed)|Jc 2:5-7|
ἁγνίζω (n°48)|purify (self)|Jc 4:8|
ἀποθησαυρίζω (n°597)|lay up in store|1 Tim 6:17-19|
ἀρέσκω (n°700)|please|1 Thess 4:1|
ὀλολύζω (n°3649)|wholly|Jc 5:1|
λούω (n°3068)|Lydda|Heb 10:22|
νοιέω (n°3539)|consider, perceive, think, understand|2 Tim 2:7|
φορέω (n°5409)|bear, wear|Jc 2:1-4|
λογομαχέω (n°3054)|strive about words|2 Tim 2:14|
θερμαίνω (n°2328)|(be) warm(-ed, self)|Jc 2:14-16|
εὐχαριστέω (n°2168)|(give) thank(-ful, -s)|1 Thess 5:18|
ἐπακολουθέω (n°1872)|follow (after)|1 Tim 5:9-10|
περίκειμαι (n°4029)|be bound (compassed) with, hang about|Heb 12:1-2|
ὑποδέχομαι (n°5264)|receive|Jc 2:20-26|
σαλεύω (n°4531)|move, shake (together),  which can(-not) be shaken, stir up|2 Thess 2:1-2|
ἐγείρω (n°1453)|awake, lift (up), raise (again, up), rear up, (a-)rise  (again, up), stand, take up|2 Tim 2:8|
οἰκοδομέω (n°3618)|(be in) build(-er, -ing, up), edify,  embolden|1 Thess 5:11|
ἀναλογίζομαι (n°357)|consider|Heb 12:3|
ἀγρυπνέω (n°69)|watch|Heb 13:17|
πιστεύω (n°4100)|believe(-r), commit (to trust), put  in trust with|Jc 2:20-26|
στήκω (n°4739)|stand (fast)|2 Thess 2:15|
βεβαιόω (n°950)|confirm, (e-)stablish|Heb 13:9|
δεικνύω (n°1166)|fear|Jc 3:13-14|
καθίστημι (n°2525)|appoint, be, conduct, make, ordain,  set|Jc 4:4|
βρύω (n°1032)|meat,  victuals|Jc 3:8-12|
παιδεύω (n°3811)|chasten(-ise), instruct, learn, teach|2 Tim 2:25|
συγκακοπαθέω (n°4777)|be partaker  of afflictions|2 Tim 1:8|
χρή (n°5534)|ought|Jc 3:8-12|
ὑπομιμνήσκω (n°5279)|put in mind, remember, bring to (put in)  remembrance|2 Tim 2:14|
ἐνεργέω (n°1754)|do, (be) effectual (fervent), be  mighty in, shew forth self, work (effectually in)|Jc 5:16|
ὁρκίζω (n°3726)|adjure, charge|1 Thess 5:27|
ἐλέγχω (n°1651)|miserable|2 Tim 4:2|
ἀντίκειμαι (n°480)|adversary, be contrary, oppose|1 Tim 5:14|
δέχομαι (n°1209)|bind, be in bonds, knit, tie, wind|Jc 1:21|
καταράομαι (n°2672)|curse|Jc 3:8-12|
ἐκβάλλω (n°1544)|bring forth,  cast (forth, out), drive (out), expel, leave, pluck (pull, take,  thrust) out, put forth (out), send away (forth, out)|Jc 2:20-26|
κάμνω (n°2577)|and (also) if (so much as), if  but, at the least, though, yet|Heb 12:3|
ῥαντίζω (n°4472)|sprinkling|Heb 10:22|
συναναμίγνυμι (n°4874)|(have, keep) company (with)|2 Thess 3:14|
ἐπιτιμάω (n°2008)|(straitly) charge, rebuke|2 Tim 4:2|
πάρειμι (n°3918)|come, X have, be here, + lack, (be here) present|Heb 13:5-6|
εὐλογέω (n°2127)|bless,  praise|Jc 3:8-12|
διέρχομαι (n°1330)|come, depart, go (about,  abroad, everywhere, over, through, throughout), pass (by, over,  through, throughout), pierce through, travel, walk through|Heb 4:14|
ἐπιζητέω (n°1934)|desire, enquire, seek (after, for)|Heb 13:13-14|
ἀποβάλλω (n°577)|cast away|Heb 10:35|
καυχάομαι (n°2744)|(make) boast, glory, joy,  rejoice|Jc 1:9|
πλανάω (n°4105)|go astray, deceive, err, seduce, wander, be out of the way|Jc 1:16|
ἀγαθοεργέω (n°14)|do good|1 Tim 6:17-19|
εὑρίσκω (n°2147)|Euroklydon|Heb 4:16|
προκόπτω (n°4298)|increase, proceed, profit, be far spent,  wax|2 Tim 2:16|
ὑπείκω (n°5226)|submit self|Heb 13:17|
ὀνειδίζω (n°3679)|cast in teeth,  (suffer) reproach, revile, upbraid|Jc 1:5-6|
μιαίνω (n°3392)|pollution|Heb 12:14-16|
ἐπαισχύνομαι (n°1870)|be ashamed|2 Tim 1:8|
βαρέω (n°916)|burden, charge, heavy, press|1 Tim 5:16|
πληρόω (n°4137)|accomplish, X after,  (be) complete, end, expire, fill (up), fulfil, (be, make) full (come),  fully preach, perfect, supply|Jc 2:20-26|
ἀποκαλύπτω (n°601)|reveal|2 Thess 2:3|
προσέχω (n°4337)|(give) attend(-ance, -ance at, -ance to, unto), beware, be  given to, give (take) heed (to unto); have regard|1 Tim 3:8-9|
πράσσω (n°4238)|meek|1 Thess 4:11|
θροέω (n°2360)|great drop|2 Thess 2:1-2|
ἀνορθόω (n°461)|lift  (set) up, make straight|Heb 12:12|
ὑποτάσσω (n°5293)|be under  obedience (obedient), put under, subdue unto, (be, make) subject (to,  unto), be (put) in subjection (to, under), submit self unto|Jc 4:7|
περιΐστημι (n°4026)|avoid, shun, stand by (round  about)|2 Tim 2:16|
φωτίζω (n°5461)|enlighten, illuminate, (bring to,  give) light, make to see|Heb 10:32-33|
ταπεινόω (n°5013)|abase, bring low, humble (self)|Jc 4:10|
ἐπέρχομαι (n°1904)|come (in, upon)|Jc 5:1|
νίπτω (n°3538)|consider, perceive, think, understand|1 Tim 5:9-10|
ἀνθίστημι (n°436)|resist, withstand|2 Tim 4:15|
ἐνίστημι (n°1764)|come, be at hand, present|2 Thess 2:1-2|
κατέχω (n°2722)|have, hold (fast), keep (in memory),  let, X make toward, possess, retain, seize on, stay, take, withhold|Heb 10:23|
ἀτιμάζω (n°818)|despise, dishonour, suffer shame, entreat shamefully|Jc 2:5-7|
ταλαιπωρέω (n°5003)|be  afflicted|Jc 4:9|
ἐντρέπω (n°1788)|regard, (give) reference, shame|2 Thess 3:14|
ὑποφέρω (n°5297)|bear, endure|2 Tim 3:10-11|
πληροφορέω (n°4135)|most surely believe, fully  know (persuade), make full proof of|2 Tim 4:5|
φύω (n°5453)|call  (for), crow, cry|Heb 12:14-16|
ὑψηλοφρονέω (n°5309)|be highminded|1 Tim 6:17-19|
ἐπιβλέπω (n°1914)|look  upon, regard, have respect to|Jc 2:1-4|
ἀφίημι (n°863)|cry, forgive,  forsake, lay aside, leave, let (alone, be, go, have), omit, put (send)  away, remit, suffer, yield up|Heb 6:1-3|
θεωρέω (n°2334)|behold, consider, look on, perceive, see|Heb 7:4|
ὑπάρχω (n°5225)|after, behave, live|Jc 2:14-16|
οἴομαι (n°3633)|suppose, think|Jc 1:7|
σοφίζω (n°4679)|cunningly devised, make  wise|2 Tim 3:14-15|
καλοποιέω (n°2569)|well doing|2 Thess 3:13|
γρηγορεύω (n°1127)|be  vigilant, wake, (be) watch(-ful)|1 Thess 5:6|
ἀποστρέφω (n°654)|bring again, pervert, turn away (from)|Heb 12:25|
μιμέομαι (n°3401)|follower|Heb 13:7|
κατεργάζομαι (n°2716)|cause, to (deed), perform, work (out)|Jc 1:2-3|
ἐκλέγομαι (n°1586)|make choice, choose (out), chosen|Jc 2:5-7|
ἐκλύω (n°1590)|faint|Heb 12:3|
ἀφανίζω (n°853)| corrupt, disfigure, perish,  vanish away|Jc 4:14|
τεκνοτροφέω (n°5044)|bring up children|1 Tim 5:9-10|
ὑπακούω (n°5219)|hearken, be obedient to, obey|2 Thess 3:14|
ἰσχύω (n°2480)|be able, avail, can do(-not), could, be good, might,  prevail, be of strength, be whole, + much work|Jc 5:16|
στηρίζω (n°4741)|fix, (e-)stablish, stedfastly set,  strengthen|Jc 5:8|
ζωοποιέω (n°2227)|make alive, give life, quicken|1 Tim 6:13|
αὐθεντέω (n°831)|usurp authority over|1 Tim 2:11-12|
χρηματίζω (n°5537)|be called, be admonished (warned) of God, reveal, speak|Heb 12:25|
ἀλείφω (n°218)|anoint|Jc 5:14|
λανθάνω (n°2990)|hewn in stone|Heb 13:2|
μιμνήσκω (n°3403)|be mindful,  remember|Heb 13:3|
ἀσθενέω (n°770)|be diseased, impotent folk  (man), (be) sick, (be, be made) weak|Jc 5:14|
τεκνογονέω (n°5041)|bear children|1 Tim 5:14|
ἐσθίω (n°2068)|Esli|2 Thess 3:12|
ξενοδοχέω (n°3580)|lodge strangers|1 Tim 5:9-10|
διάγω (n°1236)|lead life, living|1 Tim 2:1-2|
χορτάζω (n°5526)|feed, fill, satisfy|Jc 2:14-16|
ἀνίημι (n°447)|forbear, leave, loose|Heb 13:5-6|
οἰκοδεσποτέω (n°3616)|guide the house|1 Tim 5:14|
στέλλω (n°4724)|avoid, withdraw self|2 Thess 3:6|
παρέχω (n°3930)|bring, do, give, keep, minister, offer, shew, +  trouble|1 Tim 6:17-19|
θλίβω (n°2346)|afflict, narrow, throng, suffer tribulation, trouble|1 Tim 5:9-10|
ἐνδύω (n°1746)|array, clothe (with),  endue, have (put) on|1 Thess 5:8|
κοσμέω (n°2885)|adorn, garnish, trim|1 Tim 2:9-10|
ἐξαπατάω (n°1818)|beguile, deceive|2 Thess 2:3|
γαμέω (n°1060)|marry (a wife)|1 Tim 5:14|
ὠφελέω (n°5623)|advantage,  better, prevail, profit|Heb 13:9|
παρέρχομαι (n°3928)|come (forth), go, pass (away, by, over), past, transgress|Jc 1:10|
περισσεύω (n°4052)|(make, more) abound, (have, have more) abundance (be more)  abundant, be the better, enough and to spare, exceed, excel, increase,  be left, redound, remain (over and above)|1 Thess 4:1|
καλύπτω (n°2572)|cover, hide|Jc 5:20|
φιλοτιμέομαι (n°5389)|labour, strive,  study|1 Thess 4:11|
παρίστημι (n°3936)|assist, bring before,  command, commend, give presently, present, prove, provide, shew, stand  (before, by, here, up, with), yield|2 Tim 2:15|
ἀρνέομαι (n°720)|deny, refuse|2 Tim 3:1-5|
ἐξομολογέω (n°1843)|confess, profess, promise|Jc 5:16|
ἐκδέχομαι (n°1551)|expect, look (tarry) for, wait (for)|Jc 5:7|
ἐλπίζω (n°1679)|(have, thing) hope(-d) (for), trust|1 Tim 6:17-19|
ἐνδυναμόω (n°1743)|enable, (increase in) strength(-en),  be (make) strong|2 Tim 2:1|
ἁγιάζω (n°37)|hallow, be holy, sanctify|1 Thess 5:23|
ῥιπίζω (n°4494)|toss|Jc 1:5-6|
παρακολουθέω (n°3877)|attain, follow, fully know, have  understanding|2 Tim 3:10-11|
συνδέω (n°4887)|be bound with|Heb 13:3|
παρίημι (n°3935)|hang down|Heb 12:12|
