|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
λογίζομαι (n°3049)|conclude, (ac-)count (of), + despise, esteem,  impute, lay, number, reason, reckon, suppose, think (on)|Jc 2:20-26|
ἀφανίζω (n°853)| corrupt, disfigure, perish,  vanish away|Jc 4:14|
ἐπιζητέω (n°1934)|desire, enquire, seek (after, for)|Heb 13:13-14|
ἐνδυναμόω (n°1743)|enable, (increase in) strength(-en),  be (make) strong|2 Tim 2:1|
ἀγρυπνέω (n°69)|watch|Heb 13:17|
ἀποβάλλω (n°577)|cast away|Heb 10:35|
ἐξουθενέω (n°1848)|authority, jurisdiction, liberty, power, right,  strength|1 Thess 5:20|
συναναμίγνυμι (n°4874)|(have, keep) company (with)|2 Thess 3:14|
ὑγιαίνω (n°5198)|be in health, (be safe and)  sound, (be) whole(-some)|2 Tim 1:13|
περίκειμαι (n°4029)|be bound (compassed) with, hang about|Heb 12:1-2|
κατέχω (n°2722)|have, hold (fast), keep (in memory),  let, X make toward, possess, retain, seize on, stay, take, withhold|Heb 10:23|
ἔρχομαι (n°2064)|ask, beseech, desire, intreat, pray|2 Tim 4:9|
κοσμέω (n°2885)|adorn, garnish, trim|1 Tim 2:9-10|
ἐπιστρέφω (n°1994)|come (go) again, convert, (re-)turn (about, again)|Jc 5:20|
οἰκοδεσποτέω (n°3616)|guide the house|1 Tim 5:14|
χαίρω (n°5463)|hail|1 Thess 5:16|
ξενοδοχέω (n°3580)|lodge strangers|1 Tim 5:9-10|
ὠφελέω (n°5623)|advantage,  better, prevail, profit|Heb 13:9|
ἀφίημι (n°863)|cry, forgive,  forsake, lay aside, leave, let (alone, be, go, have), omit, put (send)  away, remit, suffer, yield up|Heb 6:1-3|
ὑπακούω (n°5219)|hearken, be obedient to, obey|2 Thess 3:14|
παρέρχομαι (n°3928)|come (forth), go, pass (away, by, over), past, transgress|Jc 1:10|
ἀπολείπω (n°620)|leave, remain|2 Tim 4:13|
οἴομαι (n°3633)|suppose, think|Jc 1:7|
ἀρκέω (n°714)|be content, be enough,  suffice, be sufficient|Heb 13:5-6|
παρέχω (n°3930)|bring, do, give, keep, minister, offer, shew, +  trouble|1 Tim 6:17-19|
ἐξομολογέω (n°1843)|confess, profess, promise|Jc 5:16|
τρέχω (n°5143)|have course, run|2 Thess 3:1|
ὁρκίζω (n°3726)|adjure, charge|1 Thess 5:27|
καθεύδω (n°2518)|(be  a-)sleep|1 Thess 5:6|
ἀναλαμβάνω (n°353)|receive up, take (in, unto, up)|2 Tim 4:11|
ἐκτρέπω (n°1624)|avoid, turn (aside, out of the way)|Heb 12:13|
ἀφίστημι (n°868)|depart, draw (fall)  away, refrain, withdraw self|Heb 3:12|
στρατεύομαι (n°4754)|soldier, (go to)  war(-fare)|Jc 4:1|
εὐθυμέω (n°2114)|be of good cheer (merry)|Jc 5:13|
ἐκλύω (n°1590)|faint|Heb 12:3|
ῥιπίζω (n°4494)|toss|Jc 1:5-6|
ὑποτάσσω (n°5293)|be under  obedience (obedient), put under, subdue unto, (be, make) subject (to,  unto), be (put) in subjection (to, under), submit self unto|Jc 4:7|
ἐσθίω (n°2068)|Esli|2 Thess 3:12|
παρίημι (n°3935)|hang down|Heb 12:12|
ἀφοράω (n°872)|look|Heb 12:1-2|
ἐξαπατάω (n°1818)|beguile, deceive|2 Thess 2:3|
καταράομαι (n°2672)|curse|Jc 3:8-12|
στηρίζω (n°4741)|fix, (e-)stablish, stedfastly set,  strengthen|Jc 5:8|
περιπίπτω (n°4045)|fall among (into)|Jc 1:2-3|
τεκνογονέω (n°5041)|bear children|1 Tim 5:14|
λογομαχέω (n°3054)|strive about words|2 Tim 2:14|
ἐντρέπω (n°1788)|regard, (give) reference, shame|2 Thess 3:14|
ἁγιάζω (n°37)|hallow, be holy, sanctify|1 Thess 5:23|
ταπεινόω (n°5013)|abase, bring low, humble (self)|Jc 4:10|
καταδυναστεύω (n°2616)|oppress|Jc 2:5-7|
εὐχαριστέω (n°2168)|(give) thank(-ful, -s)|1 Thess 5:18|
κακουχέω (n°2558)|which suffer  adversity, torment|Heb 13:3|
παρατίθημι (n°3908)|allege,  commend, commit (the keeping of), put forth, set before|2 Tim 2:2|
σοφίζω (n°4679)|cunningly devised, make  wise|2 Tim 3:14-15|
ἐπίσταμαι (n°1987)|know, understand|Jc 4:14|
ὀμνύω (n°3660)|with one accord (mind)|Jc 5:12|
ἐπαισχύνομαι (n°1870)|be ashamed|2 Tim 1:8|
σαλεύω (n°4531)|move, shake (together),  which can(-not) be shaken, stir up|2 Thess 2:1-2|
μιαίνω (n°3392)|pollution|Heb 12:14-16|
πληροφορέω (n°4135)|most surely believe, fully  know (persuade), make full proof of|2 Tim 4:5|
ἀλείφω (n°218)|anoint|Jc 5:14|
τεκνοτροφέω (n°5044)|bring up children|1 Tim 5:9-10|
ἐνεργέω (n°1754)|do, (be) effectual (fervent), be  mighty in, shew forth self, work (effectually in)|Jc 5:16|
ζωοποιέω (n°2227)|make alive, give life, quicken|1 Tim 6:13|
ἀτιμάζω (n°818)|despise, dishonour, suffer shame, entreat shamefully|Jc 2:5-7|
ἁγνίζω (n°48)|purify (self)|Jc 4:8|
βρύω (n°1032)|meat,  victuals|Jc 3:8-12|
ἀρνέομαι (n°720)|deny, refuse|2 Tim 3:1-5|
εὐσεβέω (n°2151)|show piety, worship|1 Tim 5:4|
ἐργάζομαι (n°2038)|commit, do, labor  for, minister about, trade (by), work|1 Thess 4:11|
ἐκλέγομαι (n°1586)|make choice, choose (out), chosen|Jc 2:5-7|
παρίστημι (n°3936)|assist, bring before,  command, commend, give presently, present, prove, provide, shew, stand  (before, by, here, up, with), yield|2 Tim 2:15|
καταλέγω (n°2639)|take into the number|1 Tim 5:9-10|
μάχομαι (n°3164)|I, me, my|2 Tim 2:24|
καυχάομαι (n°2744)|(make) boast, glory, joy,  rejoice|Jc 1:9|
ἐπιβλέπω (n°1914)|look  upon, regard, have respect to|Jc 2:1-4|
ξενίζω (n°3579)|entertain, lodge, (think it) strange|Heb 13:2|
ὑπάρχω (n°5225)|after, behave, live|Jc 2:14-16|
θερμαίνω (n°2328)|(be) warm(-ed, self)|Jc 2:14-16|
ἐπιλαμβάνομαι (n°1949)|catch,  lay hold (up-)on, take (by, hold of, on)|1 Tim 6:17-19|
περιφέρω (n°4064)|bear (carry) about|Heb 13:9|
ἀνορθόω (n°461)|lift  (set) up, make straight|Heb 12:12|
πλουτέω (n°4147)|be  increased with goods, (be made, wax) rich|1 Tim 6:17-19|
προσέχω (n°4337)|(give) attend(-ance, -ance at, -ance to, unto), beware, be  given to, give (take) heed (to unto); have regard|1 Tim 3:8-9|
ἐπακολουθέω (n°1872)|follow (after)|1 Tim 5:9-10|
διέρχομαι (n°1330)|come, depart, go (about,  abroad, everywhere, over, through, throughout), pass (by, over,  through, throughout), pierce through, travel, walk through|Heb 4:14|
μιμνήσκω (n°3403)|be mindful,  remember|Heb 13:3|
ὑψηλοφρονέω (n°5309)|be highminded|1 Tim 6:17-19|
στέλλω (n°4724)|avoid, withdraw self|2 Thess 3:6|
καθίζω (n°2523)|continue, set, sit (down), tarry|Heb 12:1-2|
κηρύσσω (n°2784)|whale|2 Tim 4:2|
ἐπιτιμάω (n°2008)|(straitly) charge, rebuke|2 Tim 4:2|
νίπτω (n°3538)|consider, perceive, think, understand|1 Tim 5:9-10|
εἰρηνεύω (n°1514)|be at (have, live in) peace, live  peaceably|1 Thess 5:13|
σβέννυμι (n°4570)|thee, thou, X thy house|1 Thess 5:19|
πλανάω (n°4105)|go astray, deceive, err, seduce, wander, be out of the way|Jc 1:16|
ἀναθεωρέω (n°333)|behold, consider|Heb 13:7|
χορτάζω (n°5526)|feed, fill, satisfy|Jc 2:14-16|
ἀντίκειμαι (n°480)|adversary, be contrary, oppose|1 Tim 5:14|
ἀρέσκω (n°700)|please|1 Thess 4:1|
δαμάζω (n°1150)|heifer|Jc 3:8-12|
ἐνοχλέω (n°1776)|trouble|Heb 12:14-16|
περιΐστημι (n°4026)|avoid, shun, stand by (round  about)|2 Tim 2:16|
ἀναλογίζομαι (n°357)|consider|Heb 12:3|
ἐνδύω (n°1746)|array, clothe (with),  endue, have (put) on|1 Thess 5:8|
ἐπέρχομαι (n°1904)|come (in, upon)|Jc 5:1|
χρή (n°5534)|ought|Jc 3:8-12|
ὑπομιμνήσκω (n°5279)|put in mind, remember, bring to (put in)  remembrance|2 Tim 2:14|
θλίβω (n°2346)|afflict, narrow, throng, suffer tribulation, trouble|1 Tim 5:9-10|
διακονέω (n°1247)|(ad-)minister (unto), serve, use the office of a deacon|1 Tim 3:10|
φιλοτιμέομαι (n°5389)|labour, strive,  study|1 Thess 4:11|
ἐκκακέω (n°1573)|faint, be weary|2 Thess 3:13|
σκληρύνω (n°4645)|harden|Heb 3:13|
ἐπαίρω (n°1869)|exalt  self, poise (lift, take) up|1 Tim 2:8|
ἀποθησαυρίζω (n°597)|lay up in store|1 Tim 6:17-19|
παραμυθέομαι (n°3888)|comfort|1 Thess 5:14|
θαῤῥέω (n°2292)|be bold, X boldly, have  confidence, be confident|Heb 13:5-6|
ὀνειδίζω (n°3679)|cast in teeth,  (suffer) reproach, revile, upbraid|Jc 1:5-6|
νοιέω (n°3539)|consider, perceive, think, understand|2 Tim 2:7|
ἐκβάλλω (n°1544)|bring forth,  cast (forth, out), drive (out), expel, leave, pluck (pull, take,  thrust) out, put forth (out), send away (forth, out)|Jc 2:20-26|
κατακαυχάομαι (n°2620)|boast (against),  glory, rejoice against|Jc 3:14|
ἀποκαλύπτω (n°601)|reveal|2 Thess 2:3|
παιδεύω (n°3811)|chasten(-ise), instruct, learn, teach|2 Tim 2:25|
ἑλκύω (n°1670)| Gentile, Greek|Jc 2:5-7|
μεταλαμβάνω (n°3335)|eat, have, be partaker, receive, take|2 Tim 2:6|
ἄγω (n°71)|manner of  life|Jc 5:1|
ἰάομαι (n°2390)|Jared|Jc 5:16|
ἀγαθοεργέω (n°14)|do good|1 Tim 6:17-19|
δουλεύω (n°1398)|be in bondage, (do) serve(-ice)|1 Tim 6:2|
κατοικέω (n°2730)|dwell(-er), inhabitant(-ter)|Jc 4:5|
φύω (n°5453)|call  (for), crow, cry|Heb 12:14-16|
ἀποστρέφω (n°654)|bring again, pervert, turn away (from)|Heb 12:25|
ἀπόλλυμι (n°622)|destroy, die, lose, mar,  perish|Jc 4:12|
ἀπέχω (n°568)|be, have, receive|1 Thess 5:22|
δεικνύω (n°1166)|fear|Jc 3:13-14|
παρακολουθέω (n°3877)|attain, follow, fully know, have  understanding|2 Tim 3:10-11|
ταλαιπωρέω (n°5003)|be  afflicted|Jc 4:9|
ἀσθενέω (n°770)|be diseased, impotent folk  (man), (be) sick, (be, be made) weak|Jc 5:14|
φωτίζω (n°5461)|enlighten, illuminate, (bring to,  give) light, make to see|Heb 10:32-33|
ῥαντίζω (n°4472)|sprinkling|Heb 10:22|
θεωρέω (n°2334)|behold, consider, look on, perceive, see|Heb 7:4|
ὑποδέχομαι (n°5264)|receive|Jc 2:20-26|
ἐνοικέω (n°1774)|dwell in|2 Tim 1:14|
ἀγωνίζομαι (n°75)|fight, labor fervently, strive|1 Tim 6:12|
ἀνίημι (n°447)|forbear, leave, loose|Heb 13:5-6|
διάγω (n°1236)|lead life, living|1 Tim 2:1-2|
παραλαμβάνω (n°3880)|receive, take (unto, with)|Heb 12:28|
πράσσω (n°4238)|meek|1 Thess 4:11|
στήκω (n°4739)|stand (fast)|2 Thess 2:15|
ἰσχύω (n°2480)|be able, avail, can do(-not), could, be good, might,  prevail, be of strength, be whole, + much work|Jc 5:16|
βαρέω (n°916)|burden, charge, heavy, press|1 Tim 5:16|
πιστεύω (n°4100)|believe(-r), commit (to trust), put  in trust with|Jc 2:20-26|
μεταστρέφω (n°3344)|pervert, turn|Jc 4:9|
καθίστημι (n°2525)|appoint, be, conduct, make, ordain,  set|Jc 4:4|
ἀνεμίζω (n°416)|drive with the wind|Jc 1:5-6|
ἐπιλανθάνομαι (n°1950)|(be) forget(-ful of)|Heb 13:2|
ἐλέγχω (n°1651)|miserable|2 Tim 4:2|
παραλογίζομαι (n°3884)|beguile, deceive|Jc 1:22|
οἰκοδομέω (n°3618)|(be in) build(-er, -ing, up), edify,  embolden|1 Thess 5:11|
