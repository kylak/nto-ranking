Le nombre entre parenthèse est le nombre de fichier présent dans cette catégorie + le nombre d'hapax dans cette catégorie - 1.
Un mot grec pourrait dans l'absolu se trouver dans plusieurs catégories, "Tout" exclue.
Tout les mots de chaque catégorie sont trouvable dans "Tout".

(x, y) x est le nombre de verbe récurrent, et y le nombre de verbe total.