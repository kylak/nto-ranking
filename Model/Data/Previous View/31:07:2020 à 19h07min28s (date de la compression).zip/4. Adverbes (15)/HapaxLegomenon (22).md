|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
εἶτα (n°1534)|if, or, whether|1 Tim 3:10|
πάλιν (n°3825)|again|Heb 6:1-3|
null (n°5238.5)|?|1 Thess 5:13|
κενῶς (n°2761)|in vain|Jc 4:5|
ἄνω (n°507)|above, brim, high, up|Heb 12:14-16|
πάντοτε (n°3842)|alway(-s),  ever(-more)|1 Thess 5:16|
ἐντεῦθεν (n°1782)|(from) hence, on either side|Jc 4:1|
ἔπειτα (n°1899)|after that(-ward), then|Jc 4:14|
μήποτε (n°3379)|if  peradventure, lest (at any time, haply), not at all, whether or not|2 Tim 2:25|
ἐκεῖ (n°1563)|from that place, (from) thence, there|Jc 2:1-4|
εὐκαίρως (n°2122)|conveniently, in season|2 Tim 4:2|
ἀμέμπτως (n°274)|blameless, unblamably|1 Thess 5:23|
ὁμοίως (n°3668)|likewise, so|Jc 2:20-26|
σήμερον (n°4594)|this  (to-)day|Heb 3:13|
ἁπλῶς (n°574)|(X  here-)after, ago, at, because of, before, by (the space of), for(-th),  from, in, (out) of, off, (up-)on(-ce), since, with|Jc 1:5-6|
ἀδιαλείπτως (n°89)|without ceasing|1 Thess 5:17|
ἀκαίρως (n°171)|out of season|2 Tim 4:2|
εὐαρέστως (n°2102)|acceptably, + please well|Heb 12:28|
πλουσίως (n°4146)|abundantly, richly|1 Tim 6:17-19|
πῶς (n°4459)|how, after (by) what manner (means), that|1 Thess 4:1|
λοιπόν (n°3063)|besides, finally, furthermore, (from) henceforth,  moreover, now, + it remaineth, then|1 Thess 4:1|
πόθεν (n°4159)|whence|Jc 4:1|
