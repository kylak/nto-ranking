|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
ἄξιος (n°514)|due reward, meet, (un-)worthy|1 Tim 6:1|
ῥυπαρός (n°4508)|vile|Jc 2:1-4|
εὔκαιρος (n°2121)|convenient, in time  of need|Heb 4:16|
βοηθός (n°998)|helper|Heb 13:5-6|
βλάσφημος (n°989)|blasphemer(-mous), railing|2 Tim 3:1-5|
ξένος (n°3581)|dry  up, pine away, be ripe, wither (away)|Heb 13:9|
ἀχάριστος (n°884)|unthankful|2 Tim 3:1-5|
ἀσάλευτος (n°761)|which cannot be  moved, unmovable|Heb 12:28|
ὄψιμος (n°3797)|latter|Jc 5:7|
ἐπουράνιος (n°2032)|celestial, (in) heaven(-ly), high|Heb 3:1|
ἄτακτος (n°813)|unruly|1 Thess 5:14|
δίκαιος (n°1342)|just, meet, right(-eous)|Jc 5:16|
ἐπιεικής (n°1933)|gentle,  moderation, patient|1 Tim 3:2-4|
ὁλόκληρος (n°3648)|entire, whole|1 Thess 5:23|
ἀληθινός (n°228)|true|Heb 10:22|
ἔκγονον (n°1549)|nephew|1 Tim 5:4|
εὔχρηστος (n°2173)|profitable, meet for  use|2 Tim 4:11|
ἀσθενής (n°772)|more feeble,  impotent, sick, without strength, weak(-er, -ness, thing)|1 Thess 5:14|
ἐπιτήδειος (n°2006)|add  unto, lade, lay upon, put (up) on, set on (up),  + surname, X wound|Jc 2:14-16|
ἄσπιλος (n°784)|without spot, unspotted|1 Tim 6:14|
εὐπερίστατος (n°2139)|which doth so  easily beset|Heb 12:1-2|
δίψυχος (n°1374)|double minded|Jc 4:8|
χρήσιμος (n°5539)|profit|2 Tim 2:14|
πρώϊμος (n°4406)|early|Jc 5:7|
φιλάργυρος (n°5366)|covetous|2 Tim 3:1-5|
ἀκατάσχετος (n°183)|unruly|Jc 3:8-12|
νεόφυτος (n°3504)|novice|1 Tim 3:6|
εὐμετάδοτος (n°2130)|ready to distribute|1 Tim 6:17-19|
φιλήδονος (n°5369)|lover of  pleasure|2 Tim 3:1-5|
ἀνέγκλητος (n°410)|blameless|1 Tim 3:10|
φιλόξενος (n°5382)|given to (lover  of, use) hospitality|1 Tim 3:2-4|
κοινωνικός (n°2843)|willing to  communicate|1 Tim 6:17-19|
ἀπόδεκτος (n°587)|acceptable|1 Tim 5:4|
δέκατος (n°1182)|tenth|Heb 7:4|
μείζων (n°3187)|elder, greater(-est), more|Jc 3:1|
ὀλιγόψυχος (n°3642)|feebleminded|1 Thess 5:14|
ἐφήμερος (n°2184)|daily|Jc 2:14-16|
ταχύς (n°5036)|wall|Jc 1:19|
ἄμαχος (n°269)|not a brawler|1 Tim 3:2-4|
δόκιμος (n°1384)|approved, tried|2 Tim 2:15|
ἀκρατής (n°193)|incontinent|2 Tim 3:1-5|
προπετής (n°4312)|heady, rash(-ly)|2 Tim 3:1-5|
σώφρων (n°4998)|discreet, sober,  temperate|1 Tim 3:2-4|
ἄστοργος (n°794)|without natural affection|2 Tim 3:1-5|
ἤρεμος (n°2263)|quiet|1 Tim 2:1-2|
μωρός (n°3474)|fool(-ish, X  -ishness)|2 Tim 2:23|
ἀπειθής (n°545)|disobedient|2 Tim 3:1-5|
χωλός (n°5560)|coast, county, fields, ground,  land, region|Heb 12:13|
ὑπερήφανος (n°5244)|proud|2 Tim 3:1-5|
ἀνόσιος (n°462)|unholy|2 Tim 3:1-5|
νεωτερικός (n°3512)|youthful|2 Tim 2:22|
γυμνός (n°1131)|nakedness|Jc 2:14-16|
σοφός (n°4680)|Spain|Jc 3:13-14|
ἡσύχιος (n°2272)|peaceable, quiet|1 Tim 2:1-2|
πολυτελής (n°4185)|costly, very precious, of  great price|1 Tim 2:9-10|
πλείων (n°4119)|X above, + exceed, more  excellent,  further, (very) great(-er), long(-er), (very) many, greater (more)  part, + yet but|2 Tim 2:16|
ἀνεπίληπτος (n°423)|blameless, unrebukeable|1 Tim 6:14|
ἀμίαντος (n°283)|undefiled|Heb 13:4|
ἱερός (n°2413)|Jerusalem|2 Tim 3:14-15|
ἀλυσιτελής (n°255)|unprofitable|Heb 13:17|
ἀνήμερος (n°434)|fierce|2 Tim 3:1-5|
ὅσιος (n°3741)|holiness|1 Tim 2:8|
ἔμφυτος (n°1721)|engrafted|Jc 1:21|
ποικίλος (n°4164)|feed  (cattle), rule|Jc 1:2-3|
θανατήφορος (n°2287)|deadly|Jc 3:8-12|
φιλόθεος (n°5377)|lover of God|2 Tim 3:1-5|
ἄσπονδος (n°786)|implacable, truce-breaker|2 Tim 3:1-5|
δεξιός (n°1188)|right (hand, side)|Heb 12:1-2|
πάροινος (n°3943)|given  to wine|1 Tim 3:2-4|
πρόγονος (n°4269)|forefather, parent|1 Tim 5:4|
μέτοχος (n°3353)|fellow, partaker, partner|Heb 3:1|
φίλαυτος (n°5367)|lover of own self|2 Tim 3:1-5|
μεστός (n°3324)|fill|Jc 3:8-12|
ἁλυκός (n°252)|salt|Jc 3:8-12|
ἀνεπαίσχυντος (n°422)|blameless, unrebukeable|2 Tim 2:15|
χρυσοδακτύλιος (n°5554)|with a gold ring|Jc 2:1-4|
ἀφιλάγαθος (n°865)|despiser  of those that are good|2 Tim 3:1-5|
ἀνεξίκακος (n°420)|patient|2 Tim 2:24|
