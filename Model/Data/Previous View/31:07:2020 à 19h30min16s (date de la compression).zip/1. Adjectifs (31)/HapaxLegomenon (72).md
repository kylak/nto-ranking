|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
σώφρων (n°4998)|discreet, sober,  temperate|1 Tim 3:2-4|
ἀφιλάγαθος (n°865)|despiser  of those that are good|2 Tim 3:1-5|
δόκιμος (n°1384)|approved, tried|2 Tim 2:15|
ῥυπαρός (n°4508)|vile|Jc 2:1-4|
ἄσπονδος (n°786)|implacable, truce-breaker|2 Tim 3:1-5|
ἀνεξίκακος (n°420)|patient|2 Tim 2:24|
φιλήδονος (n°5369)|lover of  pleasure|2 Tim 3:1-5|
ἄμαχος (n°269)|not a brawler|1 Tim 3:2-4|
ἔμφυτος (n°1721)|engrafted|Jc 1:21|
ἀνόσιος (n°462)|unholy|2 Tim 3:1-5|
ἀκατάσχετος (n°183)|unruly|Jc 3:8-12|
πλείων (n°4119)|X above, + exceed, more  excellent,  further, (very) great(-er), long(-er), (very) many, greater (more)  part, + yet but|2 Tim 2:16|
μωρός (n°3474)|fool(-ish, X  -ishness)|2 Tim 2:23|
γυμνός (n°1131)|nakedness|Jc 2:14-16|
χρυσοδακτύλιος (n°5554)|with a gold ring|Jc 2:1-4|
ἀσάλευτος (n°761)|which cannot be  moved, unmovable|Heb 12:28|
ἄστοργος (n°794)|without natural affection|2 Tim 3:1-5|
ἱερός (n°2413)|Jerusalem|2 Tim 3:14-15|
μείζων (n°3187)|elder, greater(-est), more|Jc 3:1|
null (n°3512.5)|?|1 Tim 5:14|
ἄξιος (n°514)|due reward, meet, (un-)worthy|1 Tim 6:1|
ἤπιος (n°2261)|gentle|2 Tim 2:24|
εὔκαιρος (n°2121)|convenient, in time  of need|Heb 4:16|
ἀληθινός (n°228)|true|Heb 10:22|
εὐμετάδοτος (n°2130)|ready to distribute|1 Tim 6:17-19|
ἔκγονον (n°1549)|nephew|1 Tim 5:4|
φιλόξενος (n°5382)|given to (lover  of, use) hospitality|1 Tim 3:2-4|
φιλάργυρος (n°5366)|covetous|2 Tim 3:1-5|
θανατήφορος (n°2287)|deadly|Jc 3:8-12|
ὄψιμος (n°3797)|latter|Jc 5:7|
ἄτοπος (n°824)|amiss, harm,  unreasonable|2 Thess 3:2|
ἀκλινής (n°186)|without wavering|Heb 10:23|
ἀνέγκλητος (n°410)|blameless|1 Tim 3:10|
ἀπειθής (n°545)|disobedient|2 Tim 3:1-5|
ἄσπιλος (n°784)|without spot, unspotted|1 Tim 6:14|
ἁλυκός (n°252)|salt|Jc 3:8-12|
ἀλυσιτελής (n°255)|unprofitable|Heb 13:17|
ταπεινός (n°5011)|humbleness of mind, humility (of mind, loneliness (of  mind)|Jc 1:9|
ἐπιεικής (n°1933)|gentle,  moderation, patient|1 Tim 3:2-4|
πρότερος (n°4387)|former|Heb 10:32-33|
ἀπείραστος (n°551)|not to be tempted|Jc 1:13|
εὐπερίστατος (n°2139)|which doth so  easily beset|Heb 12:1-2|
ἀσθενής (n°772)|more feeble,  impotent, sick, without strength, weak(-er, -ness, thing)|1 Thess 5:14|
ἀκρατής (n°193)|incontinent|2 Tim 3:1-5|
εὔχρηστος (n°2173)|profitable, meet for  use|2 Tim 4:11|
φίλος (n°5384)|philosophy|Jc 4:4|
ἀπόδεκτος (n°587)|acceptable|1 Tim 5:4|
ὁλοτελής (n°3651)|wholly|1 Thess 5:23|
νεωτερικός (n°3512)|youthful|2 Tim 2:22|
ὑπερήφανος (n°5244)|proud|2 Tim 3:1-5|
ἄτακτος (n°813)|unruly|1 Thess 5:14|
δέκατος (n°1182)|tenth|Heb 7:4|
πάροινος (n°3943)|given  to wine|1 Tim 3:2-4|
ἐλάσσων (n°1640)|less, under, worse, younger|1 Tim 5:9-10|
δίκαιος (n°1342)|just, meet, right(-eous)|Jc 5:16|
διδακτικός (n°1317)|apt to teach|1 Tim 3:2-4|
προπετής (n°4312)|heady, rash(-ly)|2 Tim 3:1-5|
ὀρθός (n°3717)|straight, upright|Heb 12:13|
σοφός (n°4680)|Spain|Jc 3:13-14|
ὅσιος (n°3741)|holiness|1 Tim 2:8|
χρήσιμος (n°5539)|profit|2 Tim 2:14|
ἐπιτήδειος (n°2006)|add  unto, lade, lay upon, put (up) on, set on (up),  + surname, X wound|Jc 2:14-16|
ἀνήμερος (n°434)|fierce|2 Tim 3:1-5|
χαλεπός (n°5467)|fierce,  perilous|2 Tim 3:1-5|
φιλόθεος (n°5377)|lover of God|2 Tim 3:1-5|
νηφάλεος (n°3524)|sober|1 Tim 3:11|
ἀμίαντος (n°283)|undefiled|Heb 13:4|
ἤρεμος (n°2263)|quiet|1 Tim 2:1-2|
νεόφυτος (n°3504)|novice|1 Tim 3:6|
μέτοχος (n°3353)|fellow, partaker, partner|Heb 3:1|
βλάσφημος (n°989)|blasphemer(-mous), railing|2 Tim 3:1-5|
ἀχάριστος (n°884)|unthankful|2 Tim 3:1-5|
