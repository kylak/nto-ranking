|Greek word (with Strong number)|KJV translation|New Testament reference|
|:---:|-----|:---:|
κατεργάζομαι (n°2716)|cause, to (deed), perform, work (out)|Jc 1:2-3|
στέλλω (n°4724)|avoid, withdraw self|2 Thess 3:6|
ἄξιος (n°514)|due reward, meet, (un-)worthy|1 Tim 6:1|
ἔντευξις (n°1783)|intercession,  prayer|1 Tim 2:1-2|
πλέγμα (n°4117)|broidered hair|1 Tim 2:9-10|
λοιδορία (n°3059)|railing, reproach(-fully)|1 Tim 5:14|
Τρωάς (n°5174)|eat|2 Tim 4:13|
εἶτα (n°1534)|if, or, whether|1 Tim 3:10|
ὀρθοτομέω (n°3718)|come early in the morning|2 Tim 2:15|
δέχομαι (n°1209)|bind, be in bonds, knit, tie, wind|Jc 1:21|
ἐσθίω (n°2068)|Esli|2 Thess 3:12|
φύω (n°5453)|call  (for), crow, cry|Heb 12:14-16|
περιφέρω (n°4064)|bear (carry) about|Heb 13:9|
φθόνος (n°5355)|envy|Jc 4:5|
ἐλαία (n°1636)|oil|Jc 3:8-12|
ἐξομολογέω (n°1843)|confess, profess, promise|Jc 5:16|
βασιλεύς (n°935)|king|1 Tim 2:1-2|
πάλιν (n°3825)|again|Heb 6:1-3|
null (n°5238.5)|?|1 Thess 5:13|
ἀνεμίζω (n°416)|drive with the wind|Jc 1:5-6|
ἀνορθόω (n°461)|lift  (set) up, make straight|Heb 12:12|
ἀπόστολος (n°652)|apostle, messenger, he that is sent|Heb 3:1|
θάνατος (n°2288)|X deadly, (be…) death|Jc 5:20|
ἀφοράω (n°872)|look|Heb 12:1-2|
ἀγρυπνέω (n°69)|watch|Heb 13:17|
θαῤῥέω (n°2292)|be bold, X boldly, have  confidence, be confident|Heb 13:5-6|
πειρασμός (n°3986)|temptation, X try|Jc 1:2-3|
ῥυπαρός (n°4508)|vile|Jc 2:1-4|
ἐκκακέω (n°1573)|faint, be weary|2 Thess 3:13|
εὐχαριστία (n°2169)|thankfulness, (giving of) thanks(-giving)|1 Tim 2:1-2|
ἀτιμάζω (n°818)|despise, dishonour, suffer shame, entreat shamefully|Jc 2:5-7|
εὔκαιρος (n°2121)|convenient, in time  of need|Heb 4:16|
καιρός (n°2540)|Cæsar|2 Tim 3:1-5|
χορτάζω (n°5526)|feed, fill, satisfy|Jc 2:14-16|
θερμαίνω (n°2328)|(be) warm(-ed, self)|Jc 2:14-16|
ὑπεροχή (n°5247)|authority, excellency|1 Tim 2:1-2|
βοηθός (n°998)|helper|Heb 13:5-6|
ἰσχύω (n°2480)|be able, avail, can do(-not), could, be good, might,  prevail, be of strength, be whole, + much work|Jc 5:16|
βλάσφημος (n°989)|blasphemer(-mous), railing|2 Tim 3:1-5|
ξένος (n°3581)|dry  up, pine away, be ripe, wither (away)|Heb 13:9|
ἀπείθεια (n°543)|disobedience,  unbelief|Heb 4:11|
γέλως (n°1071)|laughter|Jc 4:9|
ἀφορμή (n°874)|occasion|1 Tim 5:14|
ἀχάριστος (n°884)|unthankful|2 Tim 3:1-5|
κοινωνός (n°2844)|companion, X fellowship,  partaker, partner|Heb 10:32-33|
ἀσάλευτος (n°761)|which cannot be  moved, unmovable|Heb 12:28|
γρηγορεύω (n°1127)|be  vigilant, wake, (be) watch(-ful)|1 Thess 5:6|
ὄψιμος (n°3797)|latter|Jc 5:7|
ἐπουράνιος (n°2032)|celestial, (in) heaven(-ly), high|Heb 3:1|
ἄτακτος (n°813)|unruly|1 Thess 5:14|
ὑπάγω (n°5217)|depart, get  hence, go (a-)way|Jc 2:14-16|
παρακολουθέω (n°3877)|attain, follow, fully know, have  understanding|2 Tim 3:10-11|
ἀνίημι (n°447)|forbear, leave, loose|Heb 13:5-6|
δίκαιος (n°1342)|just, meet, right(-eous)|Jc 5:16|
ῥαντίζω (n°4472)|sprinkling|Heb 10:22|
ἱματισμός (n°2441)|apparel (X -led), array, raiment, vesture|1 Tim 2:9-10|
χρή (n°5534)|ought|Jc 3:8-12|
κενῶς (n°2761)|in vain|Jc 4:5|
ἐπιεικής (n°1933)|gentle,  moderation, patient|1 Tim 3:2-4|
κλύδων (n°2830)|toss to and fro|Jc 1:5-6|
ἀντίκειμαι (n°480)|adversary, be contrary, oppose|1 Tim 5:14|
γραφή (n°1124)|scripture|Jc 2:20-26|
δοκίμιον (n°1383)|trial, trying|Jc 1:2-3|
ἡδονή (n°2237)|mint|Jc 4:1|
εὐσεβέω (n°2151)|show piety, worship|1 Tim 5:4|
ἐλέγχω (n°1651)|miserable|2 Tim 4:2|
ἐκλύω (n°1590)|faint|Heb 12:3|
ἀναθεωρέω (n°333)|behold, consider|Heb 13:7|
ὁλόκληρος (n°3648)|entire, whole|1 Thess 5:23|
ἀληθινός (n°228)|true|Heb 10:22|
ὑπάρχω (n°5225)|after, behave, live|Jc 2:14-16|
ἔκγονον (n°1549)|nephew|1 Tim 5:4|
ἀτμίς (n°822)|vapour|Jc 4:14|
τόπος (n°5117)|as large, so great (long, many, much),  these many|1 Tim 2:8|
ἰός (n°2447)|Judah|Jc 3:8-12|
παρατίθημι (n°3908)|allege,  commend, commit (the keeping of), put forth, set before|2 Tim 2:2|
ἀναλαμβάνω (n°353)|receive up, take (in, unto, up)|2 Tim 4:11|
τεκνογονέω (n°5041)|bear children|1 Tim 5:14|
εὔχρηστος (n°2173)|profitable, meet for  use|2 Tim 4:11|
ἀσθενής (n°772)|more feeble,  impotent, sick, without strength, weak(-er, -ness, thing)|1 Thess 5:14|
πρόθεσις (n°4286)|purpose, shew(-bread)|2 Tim 3:10-11|
διέρχομαι (n°1330)|come, depart, go (about,  abroad, everywhere, over, through, throughout), pass (by, over,  through, throughout), pierce through, travel, walk through|Heb 4:14|
γεννάω (n°1080)|bear,  beget, be born, bring forth, conceive, be delivered of, gender, make,  spring|2 Tim 2:23|
σταυρός (n°4716)|cross|Heb 12:1-2|
κατοικέω (n°2730)|dwell(-er), inhabitant(-ter)|Jc 4:5|
ἐπιτήδειος (n°2006)|add  unto, lade, lay upon, put (up) on, set on (up),  + surname, X wound|Jc 2:14-16|
ἄσπιλος (n°784)|without spot, unspotted|1 Tim 6:14|
Μακεδονία (n°3109)|Macedonia|1 Thess 4:10|
θροέω (n°2360)|great drop|2 Thess 2:1-2|
ταπεινόω (n°5013)|abase, bring low, humble (self)|Jc 4:10|
ἄθλησις (n°119)|fight|Heb 10:32-33|
προδότης (n°4273)|betrayer, traitor|2 Tim 3:1-5|
εὐπερίστατος (n°2139)|which doth so  easily beset|Heb 12:1-2|
μαρτυρία (n°3141)|record,  report, testimony, witness|1 Tim 3:7|
Κάρπος (n°2591)|Carpus|2 Tim 4:13|
βοήθεια (n°996)|help|Heb 4:16|
μεμβράνα (n°3200)|complainer|2 Tim 4:13|
ἀπάτη (n°539)|deceit(-ful, -fulness), deceivableness(-ving)|Heb 3:13|
ὁμοίωσις (n°3669)|similitude|Jc 3:8-12|
δίψυχος (n°1374)|double minded|Jc 4:8|
ἀναμιμνήσκω (n°363)|call to  mind, (bring to , call to, put in), remember(-brance)|Heb 10:32-33|
θεωρέω (n°2334)|behold, consider, look on, perceive, see|Heb 7:4|
γονεύς (n°1118)|parent|2 Tim 3:1-5|
βαρέω (n°916)|burden, charge, heavy, press|1 Tim 5:16|
μέλος (n°3196)|Melchi|Jc 4:1|
φελόνης (n°5341)| cloke|2 Tim 4:13|
κρίσις (n°2920)|to judge, judgment  (seat)|Jc 5:12|
αἰσχύνη (n°152)|dishonesty,  shame|Heb 12:1-2|
ἐπιτιμάω (n°2008)|(straitly) charge, rebuke|2 Tim 4:2|
τυφόω (n°5187)|high-minded, be lifted up with pride,  be proud|2 Tim 3:1-5|
τελειωτής (n°5051)|finisher|Heb 12:1-2|
καταβάλλω (n°2598)|cast down, lay|Heb 6:1-3|
μεταλαμβάνω (n°3335)|eat, have, be partaker, receive, take|2 Tim 2:6|
Λύστρα (n°3082)|ransom|2 Tim 3:10-11|
ἀμοιβή (n°287)|vine|1 Tim 5:4|
χρήσιμος (n°5539)|profit|2 Tim 2:14|
πληροφορέω (n°4135)|most surely believe, fully  know (persuade), make full proof of|2 Tim 4:5|
ὑποφέρω (n°5297)|bear, endure|2 Tim 3:10-11|
πρέπω (n°4241)|ambassage, message|1 Tim 2:9-10|
παρίημι (n°3935)|hang down|Heb 12:12|
σωφροσύνη (n°4997)|soberness, sobriety|1 Tim 2:9-10|
ὑποδέχομαι (n°5264)|receive|Jc 2:20-26|
κοσμέω (n°2885)|adorn, garnish, trim|1 Tim 2:9-10|
παρουσία (n°3952)|coming, presence|1 Thess 5:23|
ἀντιλαμβάνομαι (n°482)|help, partaker, support|1 Tim 6:2|
πρώϊμος (n°4406)|early|Jc 5:7|
ὄγκος (n°3591)|weight|Heb 12:1-2|
φιλάργυρος (n°5366)|covetous|2 Tim 3:1-5|
ἐπίσκοπος (n°1985)|bishop, overseer|1 Tim 3:2-4|
ἀκατάσχετος (n°183)|unruly|Jc 3:8-12|
νεόφυτος (n°3504)|novice|1 Tim 3:6|
εὐμετάδοτος (n°2130)|ready to distribute|1 Tim 6:17-19|
στόμα (n°4750)|edge, face, mouth|Jc 3:8-12|
ἀγαθοεργέω (n°14)|do good|1 Tim 6:17-19|
φιλονεξία (n°5381)|entertain stranger, hospitality|Heb 13:2|
βεβαιόω (n°950)|confirm, (e-)stablish|Heb 13:9|
ταπείνωσις (n°5014)|humiliation, be made low,  low estate, vile|Jc 1:10|
ἐπέρχομαι (n°1904)|come (in, upon)|Jc 5:1|
ἄνω (n°507)|above, brim, high, up|Heb 12:14-16|
οἰκοδεσποτέω (n°3616)|guide the house|1 Tim 5:14|
ἐκβάλλω (n°1544)|bring forth,  cast (forth, out), drive (out), expel, leave, pluck (pull, take,  thrust) out, put forth (out), send away (forth, out)|Jc 2:20-26|
ἀπόλαυσις (n°619)|enjoy(-ment)|1 Tim 6:17-19|
βίος (n°979)|live|1 Tim 2:1-2|
ἀσέβεια (n°763)|ungodly(-liness)|2 Tim 2:16|
ἀρνέομαι (n°720)|deny, refuse|2 Tim 3:1-5|
ἐπισυναγωγή (n°1997)|assembling (gathering) together|2 Thess 2:1-2|
πένθος (n°3997)|mourning, sorrow|Jc 4:9|
ἀντέχομαι (n°472)|hold fast,  hold to, support|1 Thess 5:14|
πιστεύω (n°4100)|believe(-r), commit (to trust), put  in trust with|Jc 2:20-26|
ἑλκύω (n°1670)| Gentile, Greek|Jc 2:5-7|
οἶνος (n°3631)|wine|1 Tim 3:8-9|
φιλήδονος (n°5369)|lover of  pleasure|2 Tim 3:1-5|
ἁγνίζω (n°48)|purify (self)|Jc 4:8|
προφήτης (n°4396)|prophet|Jc 5:10|
χάρισμα (n°5486)|(free)  gift|2 Tim 1:6|
ἐπαγγελία (n°1860)|message, promise|Heb 4:1|
νίπτω (n°3538)|consider, perceive, think, understand|1 Tim 5:9-10|
δοξάζω (n°1392)|(make) glorify(-ious), full of (have) glory, honour,  magnify|2 Thess 3:1|
ἀνέγκλητος (n°410)|blameless|1 Tim 3:10|
φιλόξενος (n°5382)|given to (lover  of, use) hospitality|1 Tim 3:2-4|
εὔχομαι (n°2172)|profitable, meet for  use|Jc 5:16|
ὑετός (n°5205)|adoption (of children, of sons)|Jc 5:7|
κάμνω (n°2577)|and (also) if (so much as), if  but, at the least, though, yet|Heb 12:3|
σβέννυμι (n°4570)|thee, thou, X thy house|1 Thess 5:19|
Ἰκόνιον (n°2430)|Iconium|2 Tim 3:10-11|
φιλαδελφία (n°5360)|brotherly love (kindness), love of  the brethren|Heb 13:1|
οἴομαι (n°3633)|suppose, think|Jc 1:7|
Ῥαάβ (n°4460)|Rahab|Jc 2:20-26|
Πιλᾶτος (n°4091)|writing table|1 Tim 6:13|
κοινωνικός (n°2843)|willing to  communicate|1 Tim 6:17-19|
ἀφίημι (n°863)|cry, forgive,  forsake, lay aside, leave, let (alone, be, go, have), omit, put (send)  away, remit, suffer, yield up|Heb 6:1-3|
θλῖψις (n°2347)|afflicted(-tion),  anguish, burdened, persecution, tribulation, trouble|Heb 10:32-33|
ἐκδέχομαι (n°1551)|expect, look (tarry) for, wait (for)|Jc 5:7|
ἁγιάζω (n°37)|hallow, be holy, sanctify|1 Thess 5:23|
κακία (n°2549)|evil, malice(-iousness),  naughtiness, wickedness|Jc 1:21|
ὀμνύω (n°3660)|with one accord (mind)|Jc 5:12|
εὑρίσκω (n°2147)|Euroklydon|Heb 4:16|
εὐχαριστέω (n°2168)|(give) thank(-ful, -s)|1 Thess 5:18|
θλίβω (n°2346)|afflict, narrow, throng, suffer tribulation, trouble|1 Tim 5:9-10|
σοφίζω (n°4679)|cunningly devised, make  wise|2 Tim 3:14-15|
ἔχθρα (n°2189)|enmity, hatred|Jc 4:4|
ἀκροθίνιον (n°205)|spoils|Heb 7:4|
ἀπόδεκτος (n°587)|acceptable|1 Tim 5:4|
δέκατος (n°1182)|tenth|Heb 7:4|
φωτίζω (n°5461)|enlighten, illuminate, (bring to,  give) light, make to see|Heb 10:32-33|
μυστήριον (n°3466)| cannot see far off|1 Tim 3:8-9|
μείζων (n°3187)|elder, greater(-est), more|Jc 3:1|
σπέρμα (n°4690)|issue, seed|2 Tim 2:8|
ἀποκαλύπτω (n°601)|reveal|2 Thess 2:3|
πάρειμι (n°3918)|come, X have, be here, + lack, (be here) present|Heb 13:5-6|
καυχάομαι (n°2744)|(make) boast, glory, joy,  rejoice|Jc 1:9|
καταστροφή (n°2692)|overthrow, subverting|2 Tim 2:14|
κατήφεια (n°2726)|heaviness|Jc 4:9|
εὐλογέω (n°2127)|bless,  praise|Jc 3:8-12|
γράμμα (n°1121)|bill, learning, letter, scripture, writing, written|2 Tim 3:14-15|
ἐπιστρέφω (n°1994)|come (go) again, convert, (re-)turn (about, again)|Jc 5:20|
κατέχω (n°2722)|have, hold (fast), keep (in memory),  let, X make toward, possess, retain, seize on, stay, take, withhold|Heb 10:23|
ἐπιποθέω (n°1971)|(earnestly) desire (greatly),  (greatly) long (after), lust|Jc 4:5|
ὀλιγόψυχος (n°3642)|feebleminded|1 Thess 5:14|
ἀφανίζω (n°853)| corrupt, disfigure, perish,  vanish away|Jc 4:14|
ζήτησις (n°2214)|question|2 Tim 2:23|
παροξυσμός (n°3948)|contention, provoke unto|Heb 10:24|
λογίζομαι (n°3049)|conclude, (ac-)count (of), + despise, esteem,  impute, lay, number, reason, reckon, suppose, think (on)|Jc 2:20-26|
αἰτία (n°156)|accusation,  case, cause, crime, fault, (wh-)ere(-fore)|2 Tim 1:6|
ἀνθίστημι (n°436)|resist, withstand|2 Tim 4:15|
ἐπισκοπέω (n°1983)|look  diligently, take the oversight|Heb 12:14-16|
ἐφήμερος (n°2184)|daily|Jc 2:14-16|
ταχύς (n°5036)|wall|Jc 1:19|
καθίστημι (n°2525)|appoint, be, conduct, make, ordain,  set|Jc 4:4|
πάντοτε (n°3842)|alway(-s),  ever(-more)|1 Thess 5:16|
ἐντεῦθεν (n°1782)|(from) hence, on either side|Jc 4:1|
ὠφελέω (n°5623)|advantage,  better, prevail, profit|Heb 13:9|
ἄμαχος (n°269)|not a brawler|1 Tim 3:2-4|
γαμέω (n°1060)|marry (a wife)|1 Tim 5:14|
ἀγαπάω (n°25)|(be-)love(-ed)|Jc 2:5-7|
ἀποστασία (n°646)|falling away, forsake|2 Thess 2:3|
ἀναζωπυρέω (n°329)|stir up|2 Tim 1:6|
δόκιμος (n°1384)|approved, tried|2 Tim 2:15|
γλῶσσα (n°1100)|bag|Jc 3:8-12|
βρέφος (n°1025)|rain|2 Tim 3:14-15|
ἐκτρέπω (n°1624)|avoid, turn (aside, out of the way)|Heb 12:13|
περισσεία (n°4050)|abundance(-ant, (-ly)),  superfluity|Jc 1:21|
ἀποστρέφω (n°654)|bring again, pervert, turn away (from)|Heb 12:25|
νομοθέτης (n°3550)|lawgiver|Jc 4:12|
τελειότης (n°5047)|perfection(-ness)|Heb 6:1-3|
παραθήκη (n°3866)|committed unto|2 Tim 1:14|
στηρίζω (n°4741)|fix, (e-)stablish, stedfastly set,  strengthen|Jc 5:8|
ἔπειτα (n°1899)|after that(-ward), then|Jc 4:14|
προκόπτω (n°4298)|increase, proceed, profit, be far spent,  wax|2 Tim 2:16|
καταδυναστεύω (n°2616)|oppress|Jc 2:5-7|
ξενίζω (n°3579)|entertain, lodge, (think it) strange|Heb 13:2|
καταράομαι (n°2672)|curse|Jc 3:8-12|
ἀπώλεια (n°684)|damnable(-nation), destruction, die, perdition, X  perish, pernicious ways, waste|2 Thess 2:3|
ἀποτρέπω (n°665)|turn away|2 Tim 3:1-5|
εὐλάβεια (n°2124)|fear(-ed)|Heb 12:28|
ἀκρατής (n°193)|incontinent|2 Tim 3:1-5|
προπετής (n°4312)|heady, rash(-ly)|2 Tim 3:1-5|
χεῖλος (n°5491)|lip, shore|Heb 13:15|
σαλεύω (n°4531)|move, shake (together),  which can(-not) be shaken, stir up|2 Thess 2:1-2|
διδάσκαλος (n°1320)|doctor,  master, teacher|Jc 3:1|
τροχιά (n°5163)|path|Heb 12:13|
βαπτισμός (n°909)|baptism, washing|Heb 6:1-3|
σώφρων (n°4998)|discreet, sober,  temperate|1 Tim 3:2-4|
ὑπομιμνήσκω (n°5279)|put in mind, remember, bring to (put in)  remembrance|2 Tim 2:14|
τεκνοτροφέω (n°5044)|bring up children|1 Tim 5:9-10|
ὀνειδίζω (n°3679)|cast in teeth,  (suffer) reproach, revile, upbraid|Jc 1:5-6|
χρυσός (n°5557)|gold|1 Tim 2:9-10|
ἄμπελος (n°288)|vine|Jc 3:8-12|
ἄστοργος (n°794)|without natural affection|2 Tim 3:1-5|
ἤρεμος (n°2263)|quiet|1 Tim 2:1-2|
ταλαιπωρέω (n°5003)|be  afflicted|Jc 4:9|
κενοφωνία (n°2757)|vain|2 Tim 2:16|
ἐκλέγομαι (n°1586)|make choice, choose (out), chosen|Jc 2:5-7|
κριτήριον (n°2922)|to judge, judgment  (seat)|Jc 2:5-7|
Ἀντιόχεια (n°490)|of Antioch|2 Tim 3:10-11|
ἀποθησαυρίζω (n°597)|lay up in store|1 Tim 6:17-19|
μωρός (n°3474)|fool(-ish, X  -ishness)|2 Tim 2:23|
ἀπειθής (n°545)|disobedient|2 Tim 3:1-5|
βρῶμα (n°1033)|meat,  victuals|Heb 13:9|
καταλέγω (n°2639)|take into the number|1 Tim 5:9-10|
χωλός (n°5560)|coast, county, fields, ground,  land, region|Heb 12:13|
μάχομαι (n°3164)|I, me, my|2 Tim 2:24|
τροφή (n°5160)|food, meat|Jc 2:14-16|
ἀρκέω (n°714)|be content, be enough,  suffice, be sufficient|Heb 13:5-6|
ἀρχηγός (n°747)|author, captain, prince|Heb 12:1-2|
σῦκον (n°4810)|accuse falsely, take by false accusation|Jc 3:8-12|
ὑπερήφανος (n°5244)|proud|2 Tim 3:1-5|
συναγωγή (n°4864)|assembly, congregation, synagogue|Jc 2:1-4|
ὑψηλοφρονέω (n°5309)|be highminded|1 Tim 6:17-19|
μισθαποδοσία (n°3405)|recompence of reward|Heb 10:35|
συγκακοπαθέω (n°4777)|be partaker  of afflictions|2 Tim 1:8|
ἀνόσιος (n°462)|unholy|2 Tim 3:1-5|
πράσσω (n°4238)|meek|1 Thess 4:11|
καταστολή (n°2689)|apparel|1 Tim 2:9-10|
νοῦς (n°3563)|mind,  understanding|2 Thess 2:1-2|
ῥίζα (n°4491)|root|Heb 12:14-16|
ὑπόδειγμα (n°5262)|en-(ex-)ample, pattern|Jc 5:10|
μιμνήσκω (n°3403)|be mindful,  remember|Heb 13:3|
πλοῦτος (n°4149)|riches|1 Tim 6:17-19|
ὑποτάσσω (n°5293)|be under  obedience (obedient), put under, subdue unto, (be, make) subject (to,  unto), be (put) in subjection (to, under), submit self unto|Jc 4:7|
νεωτερικός (n°3512)|youthful|2 Tim 2:22|
θεατρίζω (n°2301)|make a gazing stock|Heb 10:32-33|
ἔλαιον (n°1637)|oil|Jc 5:14|
ἐλπίζω (n°1679)|(have, thing) hope(-d) (for), trust|1 Tim 6:17-19|
προφητεία (n°4394)|prophecy,  prophesying|1 Thess 5:20|
εὐλογία (n°2129)|blessing (a matter of) bounty (X -tifully), fair speech|Jc 3:8-12|
εὐαγγελιστής (n°2099)|evangelist|2 Tim 4:5|
ἐπαισχύνομαι (n°1870)|be ashamed|2 Tim 1:8|
ἐπίσταμαι (n°1987)|know, understand|Jc 4:14|
ἐπακολουθέω (n°1872)|follow (after)|1 Tim 5:9-10|
κηρύσσω (n°2784)|whale|2 Tim 4:2|
μήποτε (n°3379)|if  peradventure, lest (at any time, haply), not at all, whether or not|2 Tim 2:25|
παγίς (n°3803)|snare|1 Tim 3:7|
πόλις (n°4172)|city|Heb 13:13-14|
ἐκεῖ (n°1563)|from that place, (from) thence, there|Jc 2:1-4|
ἀσθενέω (n°770)|be diseased, impotent folk  (man), (be) sick, (be, be made) weak|Jc 5:14|
γυμνός (n°1131)|nakedness|Jc 2:14-16|
συναναμίγνυμι (n°4874)|(have, keep) company (with)|2 Thess 3:14|
φιλία (n°5373)|friendship|Jc 4:4|
εὐκαίρως (n°2122)|conveniently, in season|2 Tim 4:2|
ἐπιβλέπω (n°1914)|look  upon, regard, have respect to|Jc 2:1-4|
σοφός (n°4680)|Spain|Jc 3:13-14|
ἀλείφω (n°218)|anoint|Jc 5:14|
μιμέομαι (n°3401)|follower|Heb 13:7|
πλήκτης (n°4131)|striker|1 Tim 3:2-4|
πλανάω (n°4105)|go astray, deceive, err, seduce, wander, be out of the way|Jc 1:16|
ἡσύχιος (n°2272)|peaceable, quiet|1 Tim 2:1-2|
φαίνω (n°5316)| appear, seem,  be seen, shine, X think|Jc 4:14|
ὅρκος (n°3727)|oath|Jc 5:12|
πολυτελής (n°4185)|costly, very precious, of  great price|1 Tim 2:9-10|
καθίζω (n°2523)|continue, set, sit (down), tarry|Heb 12:1-2|
στήκω (n°4739)|stand (fast)|2 Thess 2:15|
περικεφαλαία (n°4030)|helmet|1 Thess 5:8|
μαργαρίτης (n°3135)| Mary|1 Tim 2:9-10|
ἐντρέπω (n°1788)|regard, (give) reference, shame|2 Thess 3:14|
χρηματίζω (n°5537)|be called, be admonished (warned) of God, reveal, speak|Heb 12:25|
φορέω (n°5409)|bear, wear|Jc 2:1-4|
στρατεύομαι (n°4754)|soldier, (go to)  war(-fare)|Jc 4:1|
δεικνύω (n°1166)|fear|Jc 3:13-14|
παρέρχομαι (n°3928)|come (forth), go, pass (away, by, over), past, transgress|Jc 1:10|
γόνυ (n°1119)|bow the knee, kneel down|Heb 12:12|
ἀγών (n°73)|conflict, contention, fight, race|Heb 12:1-2|
πλείων (n°4119)|X above, + exceed, more  excellent,  further, (very) great(-er), long(-er), (very) many, greater (more)  part, + yet but|2 Tim 2:16|
νοιέω (n°3539)|consider, perceive, think, understand|2 Tim 2:7|
ἀνεπίληπτος (n°423)|blameless, unrebukeable|1 Tim 6:14|
πλουτέω (n°4147)|be  increased with goods, (be made, wax) rich|1 Tim 6:17-19|
λανθάνω (n°2990)|hewn in stone|Heb 13:2|
θύρα (n°2374)|shield|Jc 5:9|
πατριάρχης (n°3966)|patriarch|Heb 7:4|
κατάρα (n°2671)|curse(-d,  ing)|Jc 3:8-12|
ἀμέμπτως (n°274)|blameless, unblamably|1 Thess 5:23|
κακουχέω (n°2558)|which suffer  adversity, torment|Heb 13:3|
ἀμίαντος (n°283)|undefiled|Heb 13:4|
ἐπιζητέω (n°1934)|desire, enquire, seek (after, for)|Heb 13:13-14|
λογομαχέω (n°3054)|strive about words|2 Tim 2:14|
ἔλεος (n°1656)|liberty|Heb 4:16|
γάμος (n°1062)|Gedeon  (in the King James Version)|Heb 13:4|
ἐργάτης (n°2040)|labourer, worker(-men)|2 Tim 2:15|
ἀγωνίζομαι (n°75)|fight, labor fervently, strive|1 Tim 6:12|
ὁμοίως (n°3668)|likewise, so|Jc 2:20-26|
ἱερός (n°2413)|Jerusalem|2 Tim 3:14-15|
ἐνδύω (n°1746)|array, clothe (with),  endue, have (put) on|1 Thess 5:8|
ἀλυσιτελής (n°255)|unprofitable|Heb 13:17|
ἀνήμερος (n°434)|fierce|2 Tim 3:1-5|
ξενοδοχέω (n°3580)|lodge strangers|1 Tim 5:9-10|
ἐπιφάνεια (n°2015)|appearing, brightness|1 Tim 6:14|
μεταστρέφω (n°3344)|pervert, turn|Jc 4:9|
ὅσιος (n°3741)|holiness|1 Tim 2:8|
ἀπιστία (n°570)|unbelief|Heb 3:12|
ἔμφυτος (n°1721)|engrafted|Jc 1:21|
ῥιπίζω (n°4494)|toss|Jc 1:5-6|
εἶδος (n°1491)|appearance,  fashion, shape, sight|1 Thess 5:22|
ὑπακούω (n°5219)|hearken, be obedient to, obey|2 Thess 3:14|
Ἠσαῦ (n°2269)|Esau|Heb 12:14-16|
ὑποπόδιον (n°5286)|footstool|Jc 2:1-4|
ποικίλος (n°4164)|feed  (cattle), rule|Jc 1:2-3|
ἀναλογίζομαι (n°357)|consider|Heb 12:3|
ἄρτος (n°740)|(shew-)bread, loaf|2 Thess 3:12|
ἀρέσκω (n°700)|please|1 Thess 4:1|
θανατήφορος (n°2287)|deadly|Jc 3:8-12|
σήμερον (n°4594)|this  (to-)day|Heb 3:13|
φιλόθεος (n°5377)|lover of God|2 Tim 3:1-5|
ἁπλῶς (n°574)|(X  here-)after, ago, at, because of, before, by (the space of), for(-th),  from, in, (out) of, off, (up-)on(-ce), since, with|Jc 1:5-6|
ἐξαπατάω (n°1818)|beguile, deceive|2 Thess 2:3|
ἀδιαλείπτως (n°89)|without ceasing|1 Thess 5:17|
ὁρκίζω (n°3726)|adjure, charge|1 Thess 5:27|
ζωοποιέω (n°2227)|make alive, give life, quicken|1 Tim 6:13|
ἀκαίρως (n°171)|out of season|2 Tim 4:2|
ἐπίγνωσις (n°1922)|(ac-)knowledge(-ing, - ment)|2 Tim 2:25|
πρωτοτόκια (n°4415)|birthright|Heb 12:14-16|
ἀδηλότης (n°83)|X uncertain|1 Tim 6:17-19|
ἄσπονδος (n°786)|implacable, truce-breaker|2 Tim 3:1-5|
πόρνη (n°4204)|harlot,  whore|Jc 2:20-26|
δεξιός (n°1188)|right (hand, side)|Heb 12:1-2|
παραλογίζομαι (n°3884)|beguile, deceive|Jc 1:22|
ἔτος (n°2094)|Eve|1 Tim 5:9-10|
βιβλίον (n°975)|bill, book, scroll, writing|2 Tim 4:13|
φίλημα (n°5370)|kiss|1 Thess 5:26|
προσωποληψία (n°4382)|respect of persons|Jc 2:1-4|
πάροινος (n°3943)|given  to wine|1 Tim 3:2-4|
θεοσέβεια (n°2317)|godliness|1 Tim 2:9-10|
πρόγονος (n°4269)|forefather, parent|1 Tim 5:4|
παιδεύω (n°3811)|chasten(-ise), instruct, learn, teach|2 Tim 2:25|
εὐαρέστως (n°2102)|acceptably, + please well|Heb 12:28|
μέτοχος (n°3353)|fellow, partaker, partner|Heb 3:1|
βρῶσις (n°1035)|eating,  food, meat|Heb 12:14-16|
οἰκοδομέω (n°3618)|(be in) build(-er, -ing, up), edify,  embolden|1 Thess 5:11|
ταλαιπωρία (n°5004)|misery|Jc 5:1|
φίλαυτος (n°5367)|lover of own self|2 Tim 3:1-5|
μεστός (n°3324)|fill|Jc 3:8-12|
ἁλυκός (n°252)|salt|Jc 3:8-12|
περίκειμαι (n°4029)|be bound (compassed) with, hang about|Heb 12:1-2|
διάγω (n°1236)|lead life, living|1 Tim 2:1-2|
ἀποβάλλω (n°577)|cast away|Heb 10:35|
ἀλαζών (n°213)|unutterable, which cannot be uttered|2 Tim 3:1-5|
λούω (n°3068)|Lydda|Heb 10:22|
δουλεύω (n°1398)|be in bondage, (do) serve(-ice)|1 Tim 6:2|
Λουκᾶς (n°3065)|washing|2 Tim 4:11|
ὑποτύπωσις (n°5296)|form, pattern|2 Tim 1:13|
ἀνεπαίσχυντος (n°422)|blameless, unrebukeable|2 Tim 2:15|
ὀλολύζω (n°3649)|wholly|Jc 5:1|
ὀπή (n°3692)|cave, place|Jc 3:8-12|
ποιητής (n°4163)|divers,  manifold|Jc 1:22|
μόρφωσις (n°3446)|form|2 Tim 3:1-5|
ἐνοχλέω (n°1776)|trouble|Heb 12:14-16|
παρέχω (n°3930)|bring, do, give, keep, minister, offer, shew, +  trouble|1 Tim 6:17-19|
θάλασσα (n°2281)|sea|Jc 1:5-6|
βρύω (n°1032)|meat,  victuals|Jc 3:8-12|
χρυσοδακτύλιος (n°5554)|with a gold ring|Jc 2:1-4|
πλῆθος (n°4128)|bundle,  company, multitude|Jc 5:20|
θυσία (n°2378)|sacrifice|Heb 13:15|
ἀνάστασις (n°386)|raised to  life again, resurrection, rise from the dead, that should rise, rising  again|Heb 6:1-3|
σημειόω (n°4593)|note|2 Thess 3:14|
Δαβίδ (n°1138)|David|2 Tim 2:8|
πλουσίως (n°4146)|abundantly, richly|1 Tim 6:17-19|
πικρία (n°4088)|bitterness|Heb 12:14-16|
ἀξιόω (n°515)|desire, think good, count (think)  worthy|1 Tim 5:17|
ἀφιλάγαθος (n°865)|despiser  of those that are good|2 Tim 3:1-5|
πῶς (n°4459)|how, after (by) what manner (means), that|1 Thess 4:1|
ἀνεξίκακος (n°420)|patient|2 Tim 2:24|
εὐθυμέω (n°2114)|be of good cheer (merry)|Jc 5:13|
προσέχω (n°4337)|(give) attend(-ance, -ance at, -ance to, unto), beware, be  given to, give (take) heed (to unto); have regard|1 Tim 3:8-9|
ἔθος (n°1485)|custom, manner, be  wont|Heb 10:25|
χόρτος (n°5528)|entreat, use|Jc 1:10|
ὕψος (n°5311)|be exalted, height,  (on) high|Jc 1:9|
φιλοτιμέομαι (n°5389)|labour, strive,  study|1 Thess 4:11|
καλύπτω (n°2572)|cover, hide|Jc 5:20|
λοιπόν (n°3063)|besides, finally, furthermore, (from) henceforth,  moreover, now, + it remaineth, then|1 Thess 4:1|
ἐνεργέω (n°1754)|do, (be) effectual (fervent), be  mighty in, shew forth self, work (effectually in)|Jc 5:16|
συκῆ (n°4808)|fig tree|Jc 3:8-12|
πόθεν (n°4159)|whence|Jc 4:1|
μιαίνω (n°3392)|pollution|Heb 12:14-16|
